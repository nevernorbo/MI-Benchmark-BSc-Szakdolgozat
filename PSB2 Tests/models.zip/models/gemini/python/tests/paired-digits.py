def paired_digits(digits):
  """
  This function takes a string of digits and returns the sum of digits whose following digit is the same.

  Args:
      digits: The string of digits.

  Returns:
      The sum of digits whose following digit is the same.
  """
  sum = 0
  for i in range(len(digits) - 1):
    if digits[i] == digits[i + 1]:
      sum += int(digits[i])
  return sum

# # Example usage
# digits = "12234456"
# result = sum_adjacent_digits(digits)
# print(result)  # Output: 8
