import math

def vector_distance(v1, v2):
  """
  This function calculates the Euclidean distance between two n-dimensional vectors.

  Args:
      v1: A list of floats representing the first n-dimensional vector.
      v2: A list of floats representing the second n-dimensional vector.

  Returns:
      The Euclidean distance between the two vectors.
  """
  if len(v1) != len(v2):
    raise ValueError("Vectors must have the same dimensions")
  distance_squared = sum((a - b) ** 2 for a, b in zip(v1, v2))
  return math.sqrt(distance_squared)

# # Example usage
# vector1 = [1.0, 2.0, 3.0]
# vector2 = [4.0, 5.0, 6.0]
# distance = euclidean_distance(vector1, vector2)
# print(f"Euclidean distance: {distance:.2f}")
