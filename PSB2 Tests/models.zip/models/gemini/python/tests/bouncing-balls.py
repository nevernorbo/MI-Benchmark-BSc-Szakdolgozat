def bouncing_balls(starting_height, bounce_index, num_bounces):
  """
  This function calculates the total distance traveled by a bouncing ball 
  after a certain number of bounces.

  Args:
      starting_height: The initial height from which the ball is dropped.
      bounce_index: The ratio of the first bounce height to the starting height.
      num_bounces: The number of times the ball bounces.

  Returns:
      The total distance traveled by the ball.
  """
  # Calculate the distance traveled down on the first bounce
  downward_distance = starting_height

  # Calculate the total distance traveled up during bounces
  total_upward_distance = 0
  for _ in range(1, num_bounces + 1):
    # Height after each bounce is starting_height * (bounce_index ^ bounce_number)
    bounce_height = starting_height * (bounce_index ** _)
    total_upward_distance += bounce_height

  # Total distance is sum of downward distances and upward distances
  total_distance = downward_distance + (2 * total_upward_distance)
  return total_distance

# # Example usage
# starting_height = 10
# bounce_index = 0.75  # Height of first bounce is 75% of starting height
# num_bounces = 3

# total_distance = calculate_total_distance(starting_height, bounce_index, num_bounces)
# print(f"Total distance traveled: {total_distance}")  # Output: Total distance traveled: 27.5
