def substitution_cipher(cipher_from, cipher_to, message):
  """
  This function deciphers a message using a Caesar cipher defined by two strings.

  Args:
      cipher_from: A string representing the original characters in the cipher.
      cipher_to: A string representing the corresponding characters in the cipher.
      message: The message to be deciphered.

  Returns:
      The deciphered message.
  """
  # Create a dictionary to map cipher characters to original characters
  cipher_dict = dict(zip(cipher_from, cipher_to))
  
  # Decipher the message by replacing characters based on the dictionary
  deciphered_message = ""
  for char in message:
    if char.isalpha():  # Only replace alphabetic characters (a-z and A-Z)
      deciphered_message += cipher_dict.get(char.upper(), char)  # Use uppercase for case-insensitive mapping
    else:
      deciphered_message += char
  return deciphered_message
