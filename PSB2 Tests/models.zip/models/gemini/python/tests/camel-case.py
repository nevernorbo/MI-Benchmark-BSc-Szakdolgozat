def camel_case(kebab_string):
  """
  This function converts a string from kebab-case to camelCase for each word group.

  Args:
      kebab_string: A string in kebab-case (words separated by hyphens).

  Returns:
      The string converted to camelCase (first letter of each word capitalized).
  """
  words = kebab_string.split()
  camel_cased_words = [word.capitalize() for word in words]
  return ''.join(camel_cased_words)

# # Example usage
# kebab_string = "camel-case example-test-string"
# camel_case_string = kebab_to_camel_case(kebab_string)
# print(camel_case_string)  # Output: camelCaseExampleTestString
