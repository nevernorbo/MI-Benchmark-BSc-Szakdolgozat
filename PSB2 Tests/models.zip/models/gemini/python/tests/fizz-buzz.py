def fizz_buzz(x):
  """
  This function takes an integer and returns "Fizz" if divisible by 3, 
  "Buzz" if divisible by 5, "FizzBuzz" if divisible by both, or the string version of x otherwise.

  Args:
      x: An integer.

  Returns:
      A string representing the fizzbuzz classification of the input integer.
  """
  # Check for divisibility by 3 and 5 first using modulo operator
  if x % 3 == 0 and x % 5 == 0:
    return "FizzBuzz"
  elif x % 3 == 0:
    return "Fizz"
  elif x % 5 == 0:
    return "Buzz"
  else:
    return str(x)

# # Example usage
# print(fizzbuzz(3))  # Output: Fizz
# print(fizzbuzz(5))  # Output: Buzz
# print(fizzbuzz(15)) # Output: FizzBuzz
# print(fizzbuzz(4))  # Output: 4
