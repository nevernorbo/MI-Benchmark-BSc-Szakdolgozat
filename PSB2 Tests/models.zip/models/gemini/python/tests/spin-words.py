def spin_words(text):
  """
  This function reverses all words of five or more letters in a string.

  Args:
      text: The input string.

  Returns:
      The string with long words reversed.
  """
  words = text.split()
  reversed_words = []
  for word in words:
    if len(word) >= 5:
      reversed_words.append(word[::-1])
    else:
      reversed_words.append(word)
  return " ".join(reversed_words)

# # Example usage
# text = "This is a string with some long words"
# reversed_text = reverse_long_words(text)
# print(reversed_text)  # Output: "This is a string htiw some gnολ words"
