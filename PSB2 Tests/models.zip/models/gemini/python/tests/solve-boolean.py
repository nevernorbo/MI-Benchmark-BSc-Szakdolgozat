def solve_boolean(expression):
  """
  This function evaluates a Boolean expression string and returns the result.

  Args:
      expression: A string representing the Boolean expression (T, F, |, &).

  Returns:
      A boolean representing the evaluated expression.
  """
  stack = []
  for char in expression:
    if char in ("T", "F"):
      stack.append(char == "T")  # Convert T/F to boolean values
    elif char == "|":
      operand2 = stack.pop()
      operand1 = stack.pop()
      stack.append(operand1 or operand2)  # Evaluate OR operation
    elif char == "&":
      operand2 = stack.pop()
      operand1 = stack.pop()
      stack.append(operand1 and operand2)  # Evaluate AND operation
    else:
      raise ValueError(f"Invalid character in expression: {char}")
  if len(stack) != 1:
    raise ValueError("Invalid expression format")
  return stack.pop()

# # Example usage
# expression = "T|F&T"
# result = evaluate_boolean_expression(expression)
# print(f"Expression '{expression}' evaluates to: {result}")
