def snow_day(hours, initial_snow, snowfall_rate, melt_rate):
  """
  This function calculates the amount of snow on the ground after a certain number of hours.

  Args:
      hours: An integer representing the number of hours.
      initial_snow: A float representing the initial amount of snow on the ground.
      snowfall_rate: A float representing the rate of snowfall per hour.
      melt_rate: A float representing the proportion of snow melting per hour.

  Returns:
      A float representing the amount of snow on the ground after the given hours.
  """
  total_snow = initial_snow
  for _ in range(hours):
    added_snow = snowfall_rate
    melted_snow = total_snow * melt_rate
    total_snow = max(0, total_snow + added_snow - melted_snow)  # Ensure snow amount is non-negative
  return total_snow

# # Example usage
# hours = 6
# initial_snow = 2.5
# snowfall_rate = 1.2
# melt_rate = 0.3
# final_snow_amount = calculate_snow_amount(hours, initial_snow, snowfall_rate, melt_rate)
# print(f"Amount of snow on the ground after {hours} hours: {final_snow_amount:.2f} inches")
