def middle_character(text):
  """
  This function takes a string as input and returns the middle character(s).

  Args:
      text: The input string.

  Returns:
      The middle character(s) of the string.
  """
  middle_index = len(text) // 2
  if len(text) % 2 == 0:
    return text[middle_index:middle_index + 2]
  else:
    return text[middle_index]

# # Example usage
# text = "Hello"
# middle = middle_char(text)
# print(middle)  # Output: "l"
