def shopping_list(prices, discounts):
  """
  This function takes vectors of prices and discounts and returns the total price after discounts.

  Args:
      prices: A vector of floats representing prices of goods.
      discounts: A vector of floats representing discount percentages.

  Returns:
      The total price after applying discounts.
  """
  if len(prices) != len(discounts):
    raise ValueError("Price and discount vectors must have the same length")
  total_price = 0
  for i in range(len(prices)):
    discount_amount = prices[i] * (discounts[i] / 100)
    total_price += prices[i] - discount_amount
  return total_price

# # Example usage
# prices = [10.50, 25.99, 8.75]
# discounts = [10, 20, 5]
# total_price = calculate_total_price(prices, discounts)
# print(f"Total price after discount: ${total_price:.2f}")
