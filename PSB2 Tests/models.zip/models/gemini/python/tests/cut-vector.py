def cut_vector(nums):
  """
  This function finds the spot in a vector where cutting it minimizes the difference 
  between the sums of the two subvectors.

  Args:
      nums: A list of positive integers.

  Returns:
      A tuple containing two lists, representing the two subvectors with the minimum difference in sums.
  """
  total_sum = sum(nums)
  min_diff = float('inf')
  best_cut = None

  # Iterate through all possible cut points
  for i in range(1, len(nums)):
    left_sum = sum(nums[:i])
    right_sum = total_sum - left_sum
    diff = abs(left_sum - right_sum)
    if diff < min_diff:
      min_diff = diff
      best_cut = i

  return nums[:best_cut], nums[best_cut:]

# # Example usage
# nums = [5, 6, 1, 2, 3]
# subvector1, subvector2 = find_min_difference_cut(nums)
# print(f"Subvector 1: {subvector1}")  # Output: Subvector 1: [5, 6, 1]
# print(f"Subvector 2: {subvector2}")  # Output: Subvector 2: [2, 3]
