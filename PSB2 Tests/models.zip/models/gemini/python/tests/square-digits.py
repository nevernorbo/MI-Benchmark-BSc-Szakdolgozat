def square_digits(n):
  """
  This function squares each digit of a positive integer and concatenates the squares into a string.

  Args:
      n: A positive integer.

  Returns:
      A string containing the squares of each digit in n.
  """
  return "".join(str(int(d) ** 2) for d in str(n))

# # Example usage
# number = 9119
# squared_digits = square_digits(number)
# print(squared_digits)  # Output: "811181"
