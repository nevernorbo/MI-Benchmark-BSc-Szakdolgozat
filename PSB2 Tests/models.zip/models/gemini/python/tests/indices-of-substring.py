def indices_of_substring(text, target):
  """
  This function finds all overlapping indices of the target substring within the text string.

  Args:
      text: The text string to search.
      target: The target substring to find.

  Returns:
      A list of integers representing the starting indices of all occurrences of the target substring in the text, including overlaps.
  """
  indices = []
  i = 0
  while i < len(text):
    index = text.find(target, i)
    if index == -1:
      break
    indices.append(index)
    i = index + 1  # Search from the character after the found occurrence

  return indices

# # Example usage
# text = "Mississippi"
# target = "iss"
# result = find_all_overlapping_indices(text, target)
# print(result)  # Output: [1, 4, 7]
