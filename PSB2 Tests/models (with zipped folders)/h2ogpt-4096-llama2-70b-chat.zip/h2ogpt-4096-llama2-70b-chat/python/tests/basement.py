def basement(vector):
    sum = 0
    for i in range(len(vector)):
        sum += vector[i]
        if sum < 0:
            return i
    return None