def shopping_list(prices, discounts):
    total_cost = 0
    for i in range(len(prices)):
        total_cost += prices[i] * (1 - discounts[i])
    return total_cost