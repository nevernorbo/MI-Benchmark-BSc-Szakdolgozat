import math

def vector_distance(v1, v2):
    """
    Calculates the Euclidean distance between two n-dimensional vectors.

    Args:
        v1 (list): The first vector.
        v2 (list): The second vector.

    Returns:
        float: The Euclidean distance between the two vectors.
    """
    # Calculate the magnitude (length) of each vector
    magnitude_v1 = math.sqrt(sum(x**2 for x in v1))
    magnitude_v2 = math.sqrt(sum(x**2 for x in v2))

    # Calculate the dot product of the two vectors
    dot_product = sum(x*y for x, y in zip(v1, v2))

    # Calculate the cosine of the angle between the two vectors
    cosine = dot_product / (magnitude_v1 * magnitude_v2)

    # Calculate the distance using the cosine and the magnitudes
    distance = math.acos(cosine) * (magnitude_v1 + magnitude_v2)

    return distance