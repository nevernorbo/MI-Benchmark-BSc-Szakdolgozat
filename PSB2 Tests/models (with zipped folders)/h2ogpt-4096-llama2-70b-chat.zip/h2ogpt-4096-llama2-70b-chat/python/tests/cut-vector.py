def cut_vector(vector):
    """
    Find the spot where the vector can be cut to make two subvectors with equal or minimally different sums.
    Return the two subvectors as two outputs.
    """
    n = len(vector)
    if n <= 1:
        return [vector], [[]]
    # Find the middle index
    mid = n // 2
    left = vector[:mid]
    right = vector[mid:]
    # Check if the sum of the two subvectors is equal or minimal
    if sum(left) == sum(right) or abs(sum(left) - sum(right)) == 1:
        return left, right
    else:
        # If the sum of the two subvectors is not equal or minimal,
        # try to find a better split by iterating through all possible indices
        best_diff = float('inf')
        for i in range(n):
            left = vector[:i]
            right = vector[i:]
            diff = abs(sum(left) - sum(right))
            if diff < best_diff:
                best_diff = diff
                best_left = left
                best_right = right
        return best_left, best_right