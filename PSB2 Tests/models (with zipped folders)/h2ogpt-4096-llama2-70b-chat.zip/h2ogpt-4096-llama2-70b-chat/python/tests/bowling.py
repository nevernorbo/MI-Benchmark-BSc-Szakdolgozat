def bowling(bowl_strings):
    # Initialize score to 0
    score = 0

    # Iterate over each bowl string
    for bowl in bowl_strings:
        # If the bowl is a strike, add 10 to the score
        if bowl == 'X':
            score += 10
        # If the bowl is a spare, add 10 + the next roll to the score
        elif bowl == '/':
            score += 10 + int(bowl_strings[bowl_strings.index(bowl) + 1])
        # Otherwise, add the number of pins knocked down to the score
        else:
            score += int(bowl)

    # Return the total score
    return score