def gcd(a, b):
    while a != 0:
        if a % b == 0:
            return b
        b -= 1
    return 1