def dice_game(n, m):
    return (n - m) / n