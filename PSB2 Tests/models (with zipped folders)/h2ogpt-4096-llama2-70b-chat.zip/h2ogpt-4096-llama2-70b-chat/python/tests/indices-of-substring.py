def indices_of_substring(text, target):
    indices = []
    i = 0
    while i < len(text):
        j = text.find(target, i)
        if j != -1:
            indices.append(j)
            i = j + len(target)
        else:
            i += 1
    return indices