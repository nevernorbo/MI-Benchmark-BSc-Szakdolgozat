def leaders(vec):
    return [x for x in vec if x >= sum(vec[i:]) for i in range(len(vec))]