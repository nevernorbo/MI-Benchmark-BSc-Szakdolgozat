def substitution_cipher(cipher1, cipher2, message):
    """
    Apply the cipher defined by cipher1 and cipher2 to the message and return the deciphered message.
    """
    # Create a dictionary to map characters in the message to their corresponding characters in the cipher
    char_map = {}
    for i in range(len(cipher1)):
        char_map[cipher1[i]] = cipher2[i]

    # Apply the cipher to the message
    deciphered_message = ''
    for char in message:
        if char in char_map:
            deciphered_message += char_map[char]
        else:
            deciphered_message += char

    return deciphered_message