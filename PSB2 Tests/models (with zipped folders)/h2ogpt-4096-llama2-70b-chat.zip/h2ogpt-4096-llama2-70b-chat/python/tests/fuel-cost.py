def fuel_cost(numbers):
    result = []
    for num in numbers:
        result.append(int(num / 3) - 2)
    return sum(result)