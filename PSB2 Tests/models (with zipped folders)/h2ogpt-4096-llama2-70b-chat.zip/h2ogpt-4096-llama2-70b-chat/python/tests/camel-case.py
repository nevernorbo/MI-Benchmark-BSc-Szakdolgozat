import re

def camel_case(string):
    """
    Convert a string in kebab-case to camelCase.
    """
    return re.sub(r"-\s+", lambda x: x.group(1).title(), string)