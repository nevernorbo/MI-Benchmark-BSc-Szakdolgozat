def luhn(digits):
    sum = 0
    for i in range(1, len(digits), 2):
        temp = digits[i] * 2
        if temp > 9:
            temp -= 9
        sum += temp
    return sum