def coin_sums(cents):
    """
    Given a number of cents, find the fewest number of US coins (pennies, nickles, dimes, quarters) needed
    to make that amount, and return the number of each type of coin as a separate output.
    """
    # Initialize the number of coins for each denomination to 0
    pennies = 0
    nickles = 0
    dimes = 0
    quarters = 0

    # Loop until the total number of cents is reached
    while cents > 0:
        # If the current amount is greater than or equal to 25, use a quarter
        if cents >= 25:
            quarters += 1
            cents -= 25
        # If the current amount is greater than or equal to 10, use a dime
        elif cents >= 10:
            dimes += 1
            cents -= 10
        # If the current amount is greater than or equal to 5, use a nickle
        elif cents >= 5:
            nickles += 1
            cents -= 5
        # Otherwise, use a penny
        else:
            pennies += 1
            cents -= 1

    # Return the number of coins for each denomination
    return pennies, nickles, dimes, quarters