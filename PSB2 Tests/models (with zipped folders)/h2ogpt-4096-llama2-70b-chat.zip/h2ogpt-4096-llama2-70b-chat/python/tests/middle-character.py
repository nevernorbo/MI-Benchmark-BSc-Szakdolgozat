def middle_character(str):
    length = len(str)
    if length % 2 == 1:
        return str[length // 2]
    else:
        return str[length // 2 - 1] + str[length // 2]