def find_pair(numbers, target):
    # Create a dictionary to map each number to its index
    num_dict = {}
    for i, num in enumerate(numbers):
        num_dict[num] = i

    for num in numbers:
        complement = target - num
        if complement in num_dict:
            return num, complement

    return None, None