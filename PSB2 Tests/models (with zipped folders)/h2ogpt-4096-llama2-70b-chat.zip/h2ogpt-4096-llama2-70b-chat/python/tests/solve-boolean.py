def solve_boolean(expression):
    # Define a dictionary to map the Boolean operators to their corresponding values
    op_dict = {'T': True, 'F': False, '|': lambda x, y: x or y, '&': lambda x, y: x and y}

    # Split the expression into tokens
    tokens = expression.split('')

    # Evaluate the expression recursively
    def evaluate(tokens):
        if len(tokens) == 1:
            return op_dict[tokens[0]]
        else:
            op = tokens.pop(0)
            return op_dict[op](evaluate(tokens), evaluate(tokens))

    return evaluate(tokens)