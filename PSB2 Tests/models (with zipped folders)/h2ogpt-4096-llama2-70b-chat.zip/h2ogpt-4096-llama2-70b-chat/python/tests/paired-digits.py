def paired_digits(str):
    sum = 0
    for i in range(len(str) - 1):
        if str[i] == str[i + 1]:
            sum += int(str[i])
    return sum