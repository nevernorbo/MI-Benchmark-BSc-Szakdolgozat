def square_digits(n):
    digits = str(n)
    squares = [digit**2 for digit in digits]
    return ''.join(squares)