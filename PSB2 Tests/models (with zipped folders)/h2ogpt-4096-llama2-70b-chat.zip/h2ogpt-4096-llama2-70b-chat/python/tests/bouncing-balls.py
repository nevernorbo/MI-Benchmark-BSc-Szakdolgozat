def calculate_bounciness_index(starting_height, height_after_first_bounce):
    return height_after_first_bounce / starting_height

def bouncing_balls(bounciness_index, number_of_bounces):
    total_distance = 0
    for i in range(number_of_bounces):
        total_distance += (bounciness_index ** i) * starting_height
    return total_distance