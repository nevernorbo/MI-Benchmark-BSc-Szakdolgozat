def leaders(nums):
    # Initialize an empty list to store the leaders
    leaders = []
    
    # Iterate through the array from right to left
    for i in range(len(nums)-1, -1, -1):
        # If the current number is greater than or equal to all the numbers to the right of it
        if all(nums[i] >= nums[j] for j in range(i+1, len(nums))):
            # Add the current number to the list of leaders
            leaders.append(nums[i])
            
    # Return the list of leaders in reverse order (to match the original order of the array)
    return leaders[::-1]