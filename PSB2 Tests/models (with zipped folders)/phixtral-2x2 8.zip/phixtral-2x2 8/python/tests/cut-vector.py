def cut_vector(vector):
    """
    This function takes a vector of positive integers and returns the optimal split point in the vector,
    and the two resulting subvectors as two outputs.
    """
    prefix_sum = [0] * (len(vector) + 1)
    for i in range(1, len(vector) + 1):
        prefix_sum[i] = prefix_sum[i - 1] + vector[i - 1]

    min_diff = float('inf')
    split_point = 0
    for i in range(1, len(vector)):
        diff = prefix_sum[i] - prefix_sum[0]
        if diff < min_diff:
            min_diff = diff
            split_point = i

    return vector[:split_point], vector[split_point:]

# # Test the function
# print(split_vector([1, 2, 3, 4, 5, 5, 4, 3, 2, 1]))  
# # Output: ([1, 2, 3, 4, 5], [5, 5, 4, 3, 2, 1])