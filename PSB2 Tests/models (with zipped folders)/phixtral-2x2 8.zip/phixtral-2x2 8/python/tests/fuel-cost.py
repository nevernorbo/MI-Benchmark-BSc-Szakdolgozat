def fuel_cost(numbers):
    # Initialize the sum to 0
    total_sum = 0
    
    # Loop through each number in the list
    for num in numbers:
        # If the number is even, add it to the total sum
        if num % 2 == 0:
            total_sum += num
            
    return total_sum

# # Test the function
# numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
# print(sum_even_numbers(numbers))  # Output: 30