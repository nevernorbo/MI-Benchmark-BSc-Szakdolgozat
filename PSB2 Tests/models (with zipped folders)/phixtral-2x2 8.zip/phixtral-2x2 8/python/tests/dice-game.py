from itertools import product

def dice_game(n, m):
    """
    This function takes the number of sides on Peter's die (n) and the number of sides on Colin's die (m)
    and returns the probability that Peter rolls strictly higher than Colin when they both roll their respective dice.
    """
    total_outcomes = len(list(product(range(1, n + 1), repeat=2)))
    peter_outcomes = len([outcome for outcome in product(range(1, n + 1), repeat=2) if outcome[0] > outcome[1]])
    return peter_outcomes / total_outcomes

# # Test the function
# print(roll_probability(6, 6))  
# # Output: 0.5