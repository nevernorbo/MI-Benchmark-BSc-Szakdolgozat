def solve_boolean(expression):
    stack = []
    for char in expression:
        if char == 'T' or char == 'T':
            stack.append(True)
        elif char == 'F' or char == 'F':
            stack.append(False)
        elif char == '|':
            stack.append(stack.pop() or stack.pop())
        elif char == '&':
            stack.append(stack.pop() and stack.pop())
    return stack.pop()

# # Test the function
# print(boolean_evaluation("T|&"))  # Output: True