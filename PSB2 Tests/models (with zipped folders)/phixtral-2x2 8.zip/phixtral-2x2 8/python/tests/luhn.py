def luhn(card_number):
    # Initialize an empty list to store the digits of the card number
    digits = [int(digit) for digit in str(card_number)]
    
    # Double every other digit starting with the second digit
    for i in range(1, len(digits), 2):
        digits[i] = digits[i] * 2
        
        # If the result is over 9, subtract 9 from it
        if digits[i] > 9:
            digits[i] -= 9
            
    # Calculate the sum of all the new digits
    total = sum(digits)
    
    # Return the last digit of the total as the Luhn's check digit
    return total % 10

# # Test the function
# card_number = 4111111111111111
# print(luhn_checksum(card_number))  #