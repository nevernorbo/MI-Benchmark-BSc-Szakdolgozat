def bowling(rolls):
    score = 0
    frame_number = 1
    roll_number = 0

    while frame_number < 11:
        roll_result = rolls[roll_number]
        roll_number += 1

        if roll_result == 10:
            # Strike, add 10 plus the next two rolls
            score += 10
            if frame_number == 11:
                score += rolls[roll_number]
            else:
                score += rolls[roll_number]
                if rolls[roll_number] == 10:
                    score += rolls[roll_number]
        elif roll_result == 0:
            # Spare, add the next roll
            score += rolls[roll_number]
            if frame_number == 11:
                score += 10
            else:
                score += rolls[roll_number]
        else:
            # Regular ball, add the current roll
            score += rolls[roll_number]
            if frame_number == 11:
                score += rolls[roll_number]
            else:
                score += rolls[roll_number]
        
        frame_number += 1

    return score