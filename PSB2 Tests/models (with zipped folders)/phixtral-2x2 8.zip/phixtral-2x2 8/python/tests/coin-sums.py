def coin_sums(amount):
    """
    This function takes a number of cents and returns the fewest number of US coins (pennies, nickels, dimes, quarters)
    needed to make that amount, and returns the number of each type of coin as a separate output.
    """
    coins = [("quarters", 25), ("dimes", 10), ("nickels", 5), ("pennies", 1)]
    output = []
    
    for coin, coin_value in coins:
        count = amount // coin_value
        amount -= count * coin_value
        output.append((coin, count))
    
    return output

# # Test the function
# print(coins_for_amount(87))  
# # Output: [('quarters', 3), ('dimes', 1), ('pennies', 2)]