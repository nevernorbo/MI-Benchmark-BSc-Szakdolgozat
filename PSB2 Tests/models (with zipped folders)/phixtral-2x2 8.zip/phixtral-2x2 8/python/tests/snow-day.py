def snow_day(hours, snow_amount, snow_fall_rate, snow_melting_rate):
    for _ in range(hours):
        snow_amount += snow_fall_rate - snow_melting_rate
    return snow_amount

# # Test the function
# hours = 3
# snow_amount = 1
# snow_fall_rate = 0.1
# snow_melting_rate = 0.05
# print(snow_amount(hours, snow_amount, snow_fall_rate, snow_melting_rate))  # Output: 0.2