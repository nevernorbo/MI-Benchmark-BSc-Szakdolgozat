def shopping_list(prices, discounts):
    total = sum(price * (1 - discount / 100) for price, discount in zip(prices, discounts))
    return total

# # Test the function
# prices = [100, 200, 300]
# discounts = [10, 20, 30]
# print(total_discounted_price(prices, discounts))  # Output: 420.0