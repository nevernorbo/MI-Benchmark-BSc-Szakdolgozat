def vector_distance(vector1, vector2):
    return sum((a - b) ** 2 for a, b in zip(vector1, vector2)) ** 0.5