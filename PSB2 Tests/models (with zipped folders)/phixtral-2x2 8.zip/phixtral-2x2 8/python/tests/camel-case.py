def camel_case(kebab_string):
    """
    This function takes a kebab-case string and returns the equivalent camelCase string.
    """
    words = kebab_string.split("-")
    camel_string = words[0].lower()
    for word in words[1:]:
        camel_string += word.title()
    return camel_string

# # Test the function
# print(kebab_to_camel("camel-case example-test-string"))  # Output: camelCaseExampleTestString