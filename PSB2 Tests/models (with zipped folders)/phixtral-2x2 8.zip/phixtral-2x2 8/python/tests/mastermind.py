def mastermind(code, guess):
    # Initialize counters for white and black pegs
    white_pegs = 0
    black_pegs = 0
    
    # Iterate through each character in the code
    for i in range(4):
        # If the characters match and the position is correct
        if code[i] == guess[i]:
            black_pegs += 1
        # If the characters match but the position is wrong
        elif code[i] in guess:
            white_pegs += 1
            
    return white_pegs, black_pegs

# # Test the function
# code = 'abcde'
# guess = 'abcdx'
# print(mastermind_clue(code, guess))  # Output: (2, 1)