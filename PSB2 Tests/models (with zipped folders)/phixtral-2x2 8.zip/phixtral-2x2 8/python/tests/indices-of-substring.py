def indices_of_substring(text, target):
    # Initialize an empty list to store the indices
    indices = []
    
    # Loop through each character in the text
    for i in range(len(text)):
        # If the current character is the start of the target string
        if text[i:i+len(target)] == target:
            # Add the index to the list of indices
            indices.append(i)
            
    return indices

# # Test the function
# text = "abababababab"
# target = "ab"
# print(find_indices(text, target))  # Output: [0, 2, 4, 6, 8]