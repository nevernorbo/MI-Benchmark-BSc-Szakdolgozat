def gcd(a, b):
    # Find the greatest common divisor (GCD) of the two numbers using Euclid's algorithm
    while b:
        a, b = b, a % b
    return a

# # Test the function
# print(largest_divisor(12, 18))  # Output: 6