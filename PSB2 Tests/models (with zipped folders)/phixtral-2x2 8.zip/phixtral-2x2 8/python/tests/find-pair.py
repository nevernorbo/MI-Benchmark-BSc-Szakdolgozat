def find_pair(vector, target):
    """
    This function takes a vector of integers and a target integer and returns a tuple
    of the two elements in the vector that sum to the target integer.
    """
    vector_set = set(vector)
    for num in vector:
        complement = target - num
        if complement in vector_set:
            return (num, complement)
    return None

# # Test the function
# print(two_sum([1, 2, 3, 4, 5, 5, 4, 3, 2, 1], 7))  
# # Output: (1, 6)