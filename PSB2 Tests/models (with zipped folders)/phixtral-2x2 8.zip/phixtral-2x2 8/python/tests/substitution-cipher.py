def substitution_cipher(cipher_string, message_string):
    return ''.join(cipher_string[i] for i in range(len(message_string)))

# # Test the function
# cipher = "abc"
# message = "def"
# print(apply_cipher(cipher, message))  # Output: ad