def spin_words(input_string):
    words = input_string.split()
    result = []
    for word in words:
        if len(word) >= 5:
            result.append(word[::-1])
        else:
            result.append(word)
    return result

# # Test the function
# print(reverse_long_words("Hello world, this is a test"))  # Output: olleH dlrow, siht is a tset