def bouncing_balls(starting_height, bounce_height, bounces):
    bouncy_index = bounce_height / starting_height
    total_distance = 0
    for _ in range(bounces):
        total_distance += bounce_height
        bounce_height *= bouncy_index
    return total_distance