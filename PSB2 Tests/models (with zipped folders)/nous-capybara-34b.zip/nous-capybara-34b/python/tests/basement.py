def basement(vec):
    n = len(vec)
    for i in range(n):
        if vec[i] < 0 or (i > 0 and sum(vec[:i+1]) < 0):
            return i
    return -1