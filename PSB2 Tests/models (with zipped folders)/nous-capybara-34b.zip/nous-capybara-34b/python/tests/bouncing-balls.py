def bounciness_index(start_height, bounce_height):
    return bounce_height / start_height

def bouncing_balls(bounciness_index, num_bounces, start_height):
    distance = start_height * (1 + bounciness_index)
    for _ in range(num_bounces - 1):
        bounce_height = start_height * bounciness_index
        distance += bounce_height * (1 + bounciness_index)
    return distance