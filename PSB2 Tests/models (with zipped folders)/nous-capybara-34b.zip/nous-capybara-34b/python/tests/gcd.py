def gcd(a, b):
    if b == 0:
        return a
    return gcd(b, a % b)

# a = 12
# b = 18
# gcd_result = gcd(a, b)
# print("Greatest common divisor:", gcd_result)