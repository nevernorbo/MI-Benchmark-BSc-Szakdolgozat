def indices_of_substring(text, target):
    if len(text) < len(target):
        raise ValueError("Target string must be shorter than or equal to the text.")

    indices = []
    for i in range(len(text) - len(target) + 1):
        if text[i:i + len(target)] == target:
            indices.append(i)

    return indices

# text = "This is a test. This is another test."
# target = "test"
# indices = find_indices(text, target)
# print("Indices of 'test' in the text:", indices)