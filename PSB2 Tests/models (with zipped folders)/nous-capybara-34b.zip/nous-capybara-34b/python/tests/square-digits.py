def square_digits(n):
    if not isinstance(n, int) or n <= 0:
        raise ValueError("Number must be a positive integer.")

    result = ""
    while n > 0:
        remainder = n % 10
        square = str(remainder ** 2)
        result = square + result
        n //= 10

    return result

# n = 1234567890
# square_digits_result = square_digits(n)
# print("Squared digits:", square_digits_result)