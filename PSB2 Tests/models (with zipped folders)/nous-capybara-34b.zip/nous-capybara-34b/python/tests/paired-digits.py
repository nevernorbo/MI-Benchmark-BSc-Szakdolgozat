def paired_digits(s):
    if not all(char.isdigit() for char in s):
        raise ValueError("String must contain only digits.")

    sum_same_followed_digits = 0
    for i in range(len(s) - 1):
        if s[i] == s[i + 1]:
            sum_same_followed_digits += int(s[i])

    return sum_same_followed_digits

# s = "123456789"
# same_followed_sum_result = same_followed_sum(s)
# print("Sum of same-followed digits:", same_followed_sum_result)