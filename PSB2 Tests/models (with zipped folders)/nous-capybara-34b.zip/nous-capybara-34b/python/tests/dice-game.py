def dice_game(n, m):
    if n <= 0 or m <= 0:
        raise ValueError("Both n and m must be positive integers.")

    total_combinations = n * m
    higher_combinations = 0
    for i in range(1, n + 1):
        for j in range(1, m + 1):
            if i > j:
                higher_combinations += 1

    probability = higher_combinations / total_combinations
    return probability

# n = 6
# m = 4
# probability = probability_higher(n, m)
# print("Probability of Peter rolling strictly higher than Colin:", probability)