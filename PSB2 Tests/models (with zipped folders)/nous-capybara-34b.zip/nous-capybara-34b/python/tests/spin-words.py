def spin_words(s):
    if not all(char.isalpha() for char in s):
        raise ValueError("String must contain only alphanumeric characters.")

    words = s.split()
    reversed_words = [word[::-1] if len(word) >= 5 else word for word in words]
    result = " ".join(reversed_words)

    return result

# s = "This is a test string with some long words."
# reversed_long_words_result = reverse_long_words(s)
# print("Reversed long words:", reversed_long_words_result)