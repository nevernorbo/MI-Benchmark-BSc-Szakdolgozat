def camel_case(string):
    words = string.split('-')
    return words[0].title() + ''.join(word.title() for word in words[1:] if word)

# input_string = "camel-case example-test-string"
# output_string = kebab_case_to_camel_case(input_string)
# print(output_string)