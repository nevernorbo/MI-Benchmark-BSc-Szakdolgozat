def coin_sums(cents):
    cents = int(cents)
    if cents < 0:
        raise ValueError("Cents must be a non-negative integer.")

    coins = [0, 0, 0, 0]
    for i in range(cents + 1):
        if (i + 25 * (i // 25) + 10 * (i // 10) + 5 * (i // 5)) == cents:
            coins[0] += (i // 1)
            coins[1] += (i // 5) - (i // 10)
            coins[2] += (i // 10) - (i // 25)
            coins[3] += (i // 25)

    return coins

# cents = 99
# coin_counts = fewest_coins(cents)
# print("{} pennies, {} nickels, {} dimes, {} quarters".format(coin_counts[0], coin_counts[1], coin_counts[2], coin_counts[3]))