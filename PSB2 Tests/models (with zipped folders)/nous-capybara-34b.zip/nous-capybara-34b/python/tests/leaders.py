def leaders(vec):
    if len(vec) <= 1:
        raise ValueError("Vector must have at least two elements.")

    leaders = []
    for i in range(len(vec)):
        if all(vec[i] >= vec[j] for j in range(i + 1, len(vec))):
            leaders.append(vec[i])

    return leaders

# vec = [3, 5, 7, 9, 11, 13, 15]
# leaders = leaders(vec)
# print("Leaders in the vector:", leaders)