def find_pair(vec, target):
    if len(vec) < 2:
        raise ValueError("Vector must have at least two elements.")

    hash_map = {}
    for i, num in enumerate(vec):
        complement = target - num
        if complement in hash_map:
            return vec[hash_map[complement]], vec[i]
        hash_map[num] = i

    raise ValueError("No two elements in the vector sum to the target.")

# vec = [3, 5, -4, 8, 11, 1, -1, 6]
# target = 10
# pair = two_sum(vec, target)
# print("Pair:", pair)