def middle_character(s):
    if len(s) % 2 == 0:
        return s[len(s) // 2 - 1] + s[len(s) // 2]
    else:
        return s[len(s) // 2]

# s = "abcdefg"
# middle_chars_result = middle_chars(s)
# print("Middle characters:", middle_chars_result)