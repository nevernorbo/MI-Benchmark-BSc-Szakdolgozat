def bowling(bowls):
    frames = [bowls[i:i+10] for i in range(0, len(bowls), 10)]
    scores = [0] * len(frames)

    for i, frame in enumerate(frames):
        if len(frame) == 2:
            if int(frame[0]) + int(frame[1]) == 10:
                scores[i] += 10
            else:
                scores[i] += int(frame[0]) + int(frame[1])
        elif len(frame) == 3:
            if int(frame[0]) + int(frame[1]) + int(frame[2]) == 10:
                scores[i] += 10
            else:
                scores[i] += int(frame[0]) + int(frame[1]) + int(frame[2])
        else:
            scores[i] += sum(int(x) for x in frame)

        if scores[i] < 10:
            scores[i] += 10

    return sum(scores)