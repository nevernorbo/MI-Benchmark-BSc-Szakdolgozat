def mastermind(code, guess):
    if len(code) != len(guess) or len(code) != 4:
        raise ValueError("Code and guess must be 4-character strings of the same length.")

    code_set = set(code)
    guess_set = set(guess)

    white_pegs = 0
    black_pegs = 0

    for char in guess_set:
        if char in code_set:
            if code.count(char) == guess.count(char):
                black_pegs += 1
            else:
                white_pegs += 1

    return white_pegs, black_pegs

# code = "ABCD"
# guess = "ABBD"
# white_pegs, black_pegs = mastermind_pegs(code, guess)
# print("White pegs:", white_pegs)
# print("Black pegs:", black_pegs)