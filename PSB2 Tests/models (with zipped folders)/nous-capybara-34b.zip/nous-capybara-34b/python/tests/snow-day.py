def snow_day(hours, snow_on_ground, snow_fall_rate, snow_melt_rate):
    if not all(isinstance(x, float) for x in [snow_on_ground, snow_fall_rate, snow_melt_rate]):
        raise ValueError("Snow on ground, snow fall rate, and snow melt rate must be floats.")

    for _ in range(hours):
        snow_on_ground += snow_fall_rate - snow_melt_rate * snow_on_ground

    return snow_on_ground

# hours = 6
# snow_on_ground = 10.0
# snow_fall_rate = 0.1
# snow_melt_rate = 0.05
# snow_on_ground_after_hours = snow_on_ground(hours, snow_on_ground, snow_fall_rate, snow_melt_rate)
# print("Snow on ground after", hours, "hours:", snow_on_ground_after_hours)