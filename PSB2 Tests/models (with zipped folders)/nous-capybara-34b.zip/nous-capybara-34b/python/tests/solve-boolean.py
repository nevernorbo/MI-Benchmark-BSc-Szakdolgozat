def solve_boolean(expr):
    if not all(char.isupper() for char in expr):
        raise ValueError("Boolean expression must contain only uppercase letters.")

    expr = expr.replace("T", "True")
    expr = expr.replace("F", "False")

    expr = eval(expr)
    return expr

# expr = "T & F | T"
# boolean_result = boolean_expression(expr)
# print("Boolean result:", boolean_result)