def luhn(vec):
    if len(vec) != 16:
        raise ValueError("Credit card number must be exactly 16 digits.")

    odd_digits = [vec[i] for i in range(1, len(vec), 2)]
    even_digits = [vec[i] for i in range(0, len(vec), 2)]

    doubled_odd_digits = [2 * digit for digit in odd_digits]
    for i, doubled_digit in enumerate(doubled_odd_digits):
        if doubled_digit > 9:
            doubled_odd_digits[i] = doubled_digit - 9

    sum_odd_digits = sum(odd_digits)
    sum_even_digits = sum(even_digits)
    sum_doubled_odd_digits = sum(doubled_odd_digits)

    total_sum = sum_odd_digits + sum_even_digits + sum_doubled_odd_digits

    return total_sum % 10 == 0

# vec = [4, 5, 6, 7, 8, 9, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
# is_valid = luhn_check(vec)
# print("Credit card number is valid:", is_valid)