def substitution_cipher(cipher1, cipher2, message):
    if not all(len(x) == len(y) for x, y in zip(cipher1, cipher2)):
        raise ValueError("Cipher pairs must be of equal length.")

    deciphered_message = ""
    for char in message:
        index = ord(char) - ord('a')
        if index < len(cipher1):
            deciphered_char = chr(ord(cipher1[index]) + ord('a'))
        else:
            deciphered_char = chr(ord(cipher2[index % len(cipher2)]) + ord('a'))
        deciphered_message += deciphered_char

    return deciphered_message

# cipher1 = "abcdefghijklmnopqrstuvwxyz"
# cipher2 = "nopqrstuvwxyzabcdefghijklm"
# message = "nopqrstuvwxyzabcdefghijklm"
# deciphered_message = decipher_message(cipher1, cipher2, message)
# print("Deciphered message:", deciphered_message)