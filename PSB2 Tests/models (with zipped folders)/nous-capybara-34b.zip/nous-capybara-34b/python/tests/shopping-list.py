def shopping_list(prices, discounts):
    if len(prices) != len(discounts):
        raise ValueError("Number of prices and discounts must match.")

    discounted_prices = [price * (1 - discount) for price, discount in zip(prices, discounts)]
    total_price = sum(discounted_prices)

    return total_price

# prices = [10.0, 20.0, 30.0, 40.0, 50.0]
# discounts = [0.1, 0.2, 0.3, 0.4, 0.5]
# total_price = discounted_total(prices, discounts)
# print("Total price after discounts:", total_price)