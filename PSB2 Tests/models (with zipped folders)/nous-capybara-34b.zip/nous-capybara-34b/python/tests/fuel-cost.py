def fuel_cost(vec):
    if len(vec) <= 0:
        raise ValueError("Vector must have at least one element.")

    new_vec = [int(round(num / 3)) - 2 for num in vec]
    return sum(new_vec)

# vec = [3, 5, 7, 9, 11, 13, 15]
# sum_new_vec = vector_sum(vec)
# print("Sum of new vector:", sum_new_vec)