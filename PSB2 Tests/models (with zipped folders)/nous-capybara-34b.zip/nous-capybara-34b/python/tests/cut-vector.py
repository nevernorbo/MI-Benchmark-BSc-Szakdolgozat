def cut_vector(vec):
    if len(vec) <= 1:
        raise ValueError("Vector must have at least two elements.")

    left = vec[:len(vec) // 2]
    right = vec[len(vec) // 2:]

    diff = abs(sum(left) - sum(right))
    if diff == 0:
        return left, right

    min_diff = diff
    best_idx = None
    for i in range(len(vec) - 1):
        left_sum = sum(vec[:i + 1])
        right_sum = sum(vec[i + 1:])
        cur_diff = abs(left_sum - right_sum)
        if cur_diff < min_diff:
            min_diff = cur_diff
            best_idx = i
        elif cur_diff == min_diff:
            best_idx = i if i < best_idx else best_idx

    return vec[:best_idx + 1], vec[best_idx + 1:]

# vec = [1, 2, 3, 4, 5, 6, 7, 8]
# left, right = split_vector(vec)
# print("Left:", left, "\nRight:", right)