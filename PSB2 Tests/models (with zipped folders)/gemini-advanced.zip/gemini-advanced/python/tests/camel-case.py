def camel_case(kebab_string):
  """Converts a kebab-case string to camelCase.

  Args:
      kebab_string: A string in kebab-case.

  Returns:
      The string converted to camelCase.
  """
  # Split the string into words
  words = kebab_string.split('-')

  # Convert the first word to lowercase
  camel_case_words = [words[0].lower()]

  # Capitalize the first letter of each subsequent word
  for word in words[1:]:
    camel_case_words.append(word.capitalize())

  # Join the words back into a string
  return ''.join(camel_case_words)

# # Example usage
# kebab_string = "camel-case-example-test-string"
# camel_case_string = kebab_to_camel_case(kebab_string)
# print(camel_case_string)  # Output: camelCaseExampleTestString
