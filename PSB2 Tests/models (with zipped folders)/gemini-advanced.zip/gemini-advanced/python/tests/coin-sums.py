def coin_sums(cents):
  """Finds the fewest US coins needed for a given amount of cents.

  Args:
      cents: An integer representing the amount in cents.

  Returns:
      A tuple containing the number of quarters, dimes, nickels, and pennies.
  """  
  quarters = cents // 25
  cents %= 25

  dimes = cents // 10
  cents %= 10

  nickels = cents // 5
  cents %= 5

  pennies = cents  

  return quarters, dimes, nickels, pennies

# # Example usage
# amount = 67
# quarters, dimes, nickels, pennies = find_fewest_coins(amount)

# print("Quarters:", quarters)
# print("Dimes:", dimes)
# print("Nickels:", nickels)
# print("Pennies:", pennies) 
