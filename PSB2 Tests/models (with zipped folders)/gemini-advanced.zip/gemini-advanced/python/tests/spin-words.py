def spin_words(text):
  """Reverses all words in a string that are five or more letters long.

  Args:
      text: A string containing words separated by spaces.

  Returns:
      A new string with the reversed long words.
  """
  words = text.split()
  reversed_words = []
  for word in words:
    if len(word) >= 5:
      reversed_words.append(word[::-1])  # Reverse the word
    else:
      reversed_words.append(word)
  return " ".join(reversed_words)

# # Example usage
# text = "This is a long sentence with words to reverse."
# reversed_text = reverse_words(text)
# print(reversed_text)  # Output: sihT si a gnol ecnetnes htiw sdro odw evreser.
