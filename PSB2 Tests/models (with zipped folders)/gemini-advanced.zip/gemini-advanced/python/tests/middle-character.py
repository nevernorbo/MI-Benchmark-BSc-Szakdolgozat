def middle_character(text):
  """
  Returns the middle character(s) of a string.

  Args:
      text: A string.

  Returns:
      A string containing the middle character(s).
  """
  middle_index = len(text) // 2
  if len(text) % 2 == 0:
    return text[middle_index - 1 : middle_index + 1]  # Even length
  else:
    return text[middle_index]                        # Odd length

# # Example usage
# text = "hello"
# middle_char = middle_character(text)
# print(middle_char)  # Output: l

# text = "banana"
# middle_char = middle_character(text)
# print(middle_char)  # Output: na 
