def shopping_list(prices, discounts):
  """Calculates the total price after applying discounts.

  Args:
      prices: A list of floats representing original prices.
      discounts: A list of floats representing percentage discounts (0-100).

  Returns:
      The total discounted price.
  """  
  total_price = 0

  for price, discount in zip(prices, discounts):
    discounted_amount = price * (discount / 100)
    discounted_price = price - discounted_amount
    total_price += discounted_price

  return total_price

# # Example usage
# prices = [10.50, 25.00, 15.75]
# discounts = [10.0, 5.0, 20.0]
# final_price = calculate_discounted_price(prices, discounts)
# print("Total price after discounts:", final_price) 
