def solve_boolean(expr):
  """Evaluates a simple Boolean expression with 'T', 'F', '&' (AND), and '|' (OR) operators.

  Args:
      expr: A string representing the Boolean expression.

  Returns:
      True or False based on the evaluation of the expression.

  Raises:
      ValueError: If the expression contains invalid characters.
  """
  def evaluate_and(left, right):
    return left and right

  def evaluate_or(left, right):
    return left or right

  tokens = expr.split()
  stack = []

  for token in tokens:
    if token == 'T':
      stack.append(True)
    elif token == 'F':
      stack.append(False)
    elif token == '&':
      right = stack.pop()
      left = stack.pop()
      stack.append(evaluate_and(left, right))
    elif token == '|':
      right = stack.pop()
      left = stack.pop()
      stack.append(evaluate_or(left, right))
    else:
      raise ValueError("Invalid character in Boolean expression.")

  if len(stack) != 1:
    raise ValueError("Invalid Boolean expression.")

  return stack.pop()  

# # Example usage
# expression = "T | T & F"
# result = evaluate_boolean_expression(expression)
# print(result)  # Output: True
