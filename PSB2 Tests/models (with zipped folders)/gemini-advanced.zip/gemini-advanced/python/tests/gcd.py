def gcd(num1, num2):
  """Calculates the greatest common divisor (GCD) of two integers.

  Args:
      num1: The first integer.
      num2: The second integer.

  Returns:
      The greatest common divisor of num1 and num2.
  """

  while num2 != 0:
    new_num2 = num1 % num2
    num1 = num2
    num2 = new_num2
  return num1

# # Example usage
# num1 = 36
# num2 = 60
# greatest_common_divisor = gcd(num1, num2)
# print("Greatest Common Divisor:", greatest_common_divisor)  # Output: Greatest Common Divisor: 12
