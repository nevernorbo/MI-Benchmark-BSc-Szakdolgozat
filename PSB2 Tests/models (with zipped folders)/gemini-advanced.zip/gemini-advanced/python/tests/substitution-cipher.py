def substitution_cipher(cipher_string1, cipher_string2, message):
  """Deciphers a message using a character cipher.

  Args:
      cipher_string1: A string representing the original characters.
      cipher_string2: A string representing the corresponding cipher characters.
      message: The encoded message string.

  Returns:
      The deciphered message.
  """  
  translation_table = dict(zip(cipher_string1, cipher_string2))
  deciphered_message = "".join(translation_table.get(char, char) for char in message) 
  return deciphered_message

# # Example usage
# cipher_string1 = "abcdefghijklmnopqrstuvwxyz"
# cipher_string2 = "zyxwvutsrqponmlkjihgfedcba"
# encoded_message = "mlkjihgfedcba"
# deciphered_message = decipher_message(cipher_string1, cipher_string2, encoded_message) 
# print(deciphered_message)  # Output: worldhello
