def find_pair(nums, target):
  """Finds two elements in a list that add up to a target.

  Args:
      nums: A list of integers.
      target: The target integer.

  Returns:
      A tuple containing the two elements that sum to the target, or None if no solution exists.
  """
  seen = {}  # A dictionary to track seen numbers

  for i, num in enumerate(nums):
    complement = target - num  # Calculate the needed complement
    if complement in seen: 
      return seen[complement], num  # Solution found!
    seen[num] = i  # Store the number and its index

  return None  # No solution found

# Example usage
# nums = [2, 7, 11, 15]
# target = 9
# result = find_two_sum(nums, target)

# if result:
#   print("Elements:", result)  # Output: Elements: (2, 7)
# else:
#   print("No two numbers sum to the target")
