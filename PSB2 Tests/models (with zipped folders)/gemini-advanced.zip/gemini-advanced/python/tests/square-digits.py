def square_digits(n):
  """Squares each digit of a positive integer and concatenates the squares into a string.

  Args:
      n: A positive integer.

  Returns:
      A string containing the squares of each digit in n.
  """
  return "".join(str(int(d) ** 2) for d in str(n))
