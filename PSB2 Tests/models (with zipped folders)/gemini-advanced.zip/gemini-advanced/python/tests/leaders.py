def leaders(nums):
    """Finds the leaders in a vector of positive integers.

    Args:
        nums: A list of positive integers.

    Returns:
        A list of leaders in the vector.
    """
    leaders = []
    current_leader = float('-inf')  # Start with a very small leader

    for num in reversed(nums):
        if num >= current_leader:
            leaders.append(num)
            current_leader = num

    return leaders[::-1]  # Reverse to get the leaders in the original order

# # Example usage
# nums = [7, 4, 5, 2, 8, 1]
# result = find_leaders(nums)
# print(result)  # Output: [8, 5, 2]
