import math

def vector_distance(v1, v2):
    """Calculates the Euclidean distance between two n-dimensional vectors.

    Args:
        v1: A list of floats representing the first n-dimensional vector.
        v2: A list of floats representing the second n-dimensional vector.

    Returns:
        The Euclidean distance between the two vectors.

    Raises:
        ValueError: If the vectors have different dimensions.
    """

    if len(v1) != len(v2):
        raise ValueError("Vectors must have the same dimensionality.")

    squared_differences = [(x1 - x2) ** 2 for x1, x2 in zip(v1, v2)]
    sum_of_squares = sum(squared_differences)
    distance = math.sqrt(sum_of_squares)

    return distance

# # Example usage
# vector1 = [1.0, 2.0, 3.0]
# vector2 = [4.0, 5.0, 6.0]

# distance = euclidean_distance(vector1, vector2)
# print(distance)  # Output: 5.196152422706632
