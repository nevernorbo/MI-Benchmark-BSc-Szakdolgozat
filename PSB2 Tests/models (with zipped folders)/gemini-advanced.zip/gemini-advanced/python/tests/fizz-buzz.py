def fizz_buzz(x):
  """
  FizzBuzz function that returns a Fizz, Buzz, FizzBuzz, or string representation of x.

  Args:
      x: An integer.

  Returns:
      A string representing the FizzBuzz output.
  """
  if x % 3 == 0 and x % 5 == 0:
    return "FizzBuzz"
  elif x % 3 == 0:
    return "Fizz"
  elif x % 5 == 0:
    return "Buzz"
  else:
    return str(x)

# # Example usage with a loop:
# for i in range(1, 16):
#   print(fizzbuzz(i))
