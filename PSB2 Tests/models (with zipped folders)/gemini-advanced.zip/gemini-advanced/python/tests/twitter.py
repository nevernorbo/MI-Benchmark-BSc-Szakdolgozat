def twitter(tweet):
  """Validates a tweet based on Twitter's original character limit (140 characters).

  Args:
      tweet: A string representing the tweet content.

  Returns:
      A string indicating the tweet's validity.
  """
  tweet_length = len(tweet)
  if tweet_length == 0:
    return "You didn't type anything"
  elif tweet_length > 140:
    return "Too many characters"
  else:
    return f"Your tweet has {tweet_length} characters"

# # Example usage (same as before)
# tweet1 = ""
# tweet2 = "This tweet has exactly 140 characters."
# tweet3 = "This tweet is too long and has more than 140 characters."

# print(validate_tweet(tweet1))  # Output: You didn't type anything
# print(validate_tweet(tweet2))  # Output: Your tweet has 38 characters
# print(validate_tweet(tweet3))  # Output: Too many characters
