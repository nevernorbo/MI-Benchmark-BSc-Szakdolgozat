def bowling(game_string):
    """Calculates the score of a 10-frame bowling game.

    Args:
        game_string: A string representing the individual bowls, e.g., "X5/9-X--81XXXXXX".

    Returns:
        The total score of the bowling game.
    """

    frame_start = 0
    score = 0
    for i in range(10):  # Process up to 10 frames
        if game_string[frame_start] == 'X':  # Strike
            score += 10 + get_next_two_rolls(game_string, frame_start + 1)
            frame_start += 1
        elif game_string[frame_start] == '/':  # Spare
            score += 10 + get_next_roll(game_string, frame_start + 1)
            frame_start += 2
        else:  # Regular frame
            roll1 = get_roll_value(game_string[frame_start])
            roll2 = get_roll_value(game_string[frame_start + 1])
            score += roll1 + roll2
            frame_start += 2

    return score

def get_roll_value(roll):
    """Gets the numeric value of a single roll."""
    if roll in '123456789':
        return int(roll)
    elif roll == '-':
        return 0
    elif roll == 'X':
        return 10
    elif roll == '/':
        return 10 - get_roll_value(roll-1)  # Previous score
    else: 
        raise ValueError("Invalid roll character")

def get_next_roll(game_string, start_index):
    """Gets the numeric value of the next roll."""
    return get_roll_value(game_string[start_index])

def get_next_two_rolls(game_string, start_index):
    """Gets the numeric value of the next two rolls."""
    return sum(get_roll_value(roll) for roll in game_string[start_index : start_index + 2]) 

# # Example usage
# game_string = "X5/9-X--81XXXXXX" 
# score = calculate_bowling_score(game_string)
# print("The score of the game is:", score) 
