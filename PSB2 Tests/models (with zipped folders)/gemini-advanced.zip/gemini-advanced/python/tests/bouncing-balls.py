def calculate_bounciness_index(starting_height, bounce_height):
  """Calculates the bounciness index of a ball."""
  return bounce_height / starting_height

def bouncing_balls(starting_height, bounce_height, num_bounces):
  """Calculates the total distance a bouncing ball travels."""
  bounciness_index = calculate_bounciness_index(starting_height, bounce_height)

  # Initial drop
  total_distance = starting_height

  # Up and down for each bounce
  for _ in range(num_bounces):
    total_distance += 2 * starting_height * bounciness_index
    starting_height *= bounciness_index

  return total_distance

# # Example usage:
# starting_height = 10  # Height in meters
# bounce_height = 6     # Height of first bounce in meters
# num_bounces = 3   

# bounciness_index = calculate_bounciness_index(starting_height, bounce_height)
# total_distance = calculate_total_distance(starting_height, bounce_height, num_bounces)

# print("Bounciness Index:", bounciness_index)
# print("Total Distance:", total_distance, "meters")
