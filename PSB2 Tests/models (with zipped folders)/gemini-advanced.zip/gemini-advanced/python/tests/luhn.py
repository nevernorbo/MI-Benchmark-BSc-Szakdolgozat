def luhn(card_number):
  """
  Validates a credit card number using Luhn's algorithm.

  Args:
      card_number: A list of 16 digits representing the credit card number.

  Returns:
      True if the card number is valid, False otherwise.
  """
  digits = list(map(int, card_number)) # Convert digits to integers
  check_digit = digits.pop()  # Remove and store the check digit

  # Double every other digit starting from the second-to-last
  digits = digits[::-1]  # Reverse for easier processing
  for i in range(0, len(digits), 2):
    digits[i] *= 2
    if digits[i] > 9:
      digits[i] -= 9

  total = sum(digits) + check_digit
  return total % 10 == 0  # Check if total is divisible by 10

# # Example usage
# card_number = [4, 2, 4, 2, 4, 2, 4, 2, 4, 2, 4, 2, 4, 2, 4, 2] 
# is_valid = validate_card_number(card_number)
# print(is_valid)  # Output: True
