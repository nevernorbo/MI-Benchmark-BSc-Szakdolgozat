def snow_day(hours, initial_snow, snowfall_rate, melt_rate):
  """
  Calculates the amount of snow on the ground after a certain number of hours.

  Args:
      hours: An integer representing the number of hours.
      initial_snow: A float representing the initial amount of snow.
      snowfall_rate: A float representing the snowfall rate per hour.
      melt_rate: A float representing the proportion of snow melting per hour (0-1).

  Returns:
      The amount of snow on the ground after the specified hours.
  """
  total_snow = initial_snow
  for _ in range(hours):
    snowfall = snowfall_rate
    melting = total_snow * melt_rate
    total_snow += snowfall - melting

  return max(total_snow, 0)  # Ensure non-negative snow amount

# # Example usage
# hours = 6
# initial_snow = 2.0
# snowfall_rate = 1.5
# melt_rate = 0.25
# final_snow_amount = calculate_snow_amount(hours, initial_snow, snowfall_rate, melt_rate)
# print("Amount of snow on the ground:", final_snow_amount)  # Output: 5.2880859375
