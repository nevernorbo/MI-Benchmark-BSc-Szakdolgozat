def indices_of_substring(text, target):
  """Finds all indices of a target substring within a text string, including overlaps.

  Args:
      text: The main string to search within.
      target: The substring to search for.

  Returns:
      A list of indices where the target substring starts within the text.
  """  
  indices = []
  i = text.find(target)  
  while i != -1:  
    indices.append(i)
    i = text.find(target, i + 1)  # Search from the next position after the current match
  return indices

# # Example usage
# text = "AAABAAABAA" 
# target = "AAAB" 
# result = find_all_overlapping_indices(text, target)
# print(result)  # Output: [0, 4] 
