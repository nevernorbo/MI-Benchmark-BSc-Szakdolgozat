def dice_game(n, m):
  """
  Calculates the probability that Peter wins when rolling n and m sided dice.

  Args:
      n: Number of sides on Peter's die.
      m: Number of sides on Colin's die.

  Returns:
      The probability that Peter wins (rolls a strictly higher number).
  """

  # Favorable outcomes: all numbers from n to m (inclusive) on Peter's die.
  favorable_outcomes = m - n + 1 

  # Total possible outcomes: n (Peter's die) * m (Colin's die)
  total_outcomes = n * m

  # Avoid division by zero
  if total_outcomes == 0:
    return 0

  return favorable_outcomes / total_outcomes

# # Example usage
# n = 6  # Peter's six-sided die
# m = 4  # Colin's four-sided die
# probability = probability_of_peter_wins(n, m)
# print("Probability of Peter winning:", probability) 
