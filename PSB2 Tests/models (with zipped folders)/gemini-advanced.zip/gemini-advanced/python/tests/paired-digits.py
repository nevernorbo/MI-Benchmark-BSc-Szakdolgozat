def paired_digits(digits_string):
  """Calculates the sum of digits whose following digit is the same.

  Args:
      digits_string: A string containing only digits.

  Returns:
      The sum of digits whose following digit is the same.
  """
  total_sum = 0
  for i in range(len(digits_string) - 1):
    if digits_string[i] == digits_string[i + 1]:
      total_sum += int(digits_string[i])
  return total_sum

# # Example usage
# digits_string = "12341212"
# sum_of_digits = sum_same_consecutive_digits(digits_string)
# print(sum_of_digits)  # Output: 4
