def cut_vector(nums):
  """Finds the cut point in a vector for balancing the sums of sub-vectors.

  Args:
      nums: A list of positive integers.

  Returns:
      A tuple containing the cut point index and the two sub-vectors.
  """
  total_sum = sum(nums)
  left_sum = 0
  min_diff = float('inf')  # Start with a large difference
  best_cut = -1

  for i in range(1, len(nums)):
    left_sum += nums[i-1]
    right_sum = total_sum - left_sum
    diff = abs(left_sum - right_sum)
    if diff < min_diff:
      min_diff = diff
      best_cut = i

  return best_cut, nums[:best_cut], nums[best_cut:]

# # Example usage
# nums = [1, 2, 3, 4, 5]
# cut_point, left_subvector, right_subvector = find_cut_point(nums)

# print("Cut point:", cut_point)
# print("Left subvector:", left_subvector)
# print("Right subvector:", right_subvector)