def mastermind(code, guess):
  """Calculates the number of black and white pegs for a Mastermind guess.

  Args:
      code: A 4-character string representing the secret code.
      guess: A 4-character string representing the player's guess.

  Returns:
      A tuple containing the number of black pegs and white pegs.
  """

  black_pegs = 0
  white_pegs = 0
  used_chars_in_code = {}  # Track used characters in the code

  # Count black pegs (correct color, correct place)
  for i in range(len(code)):
    if code[i] == guess[i]:
      black_pegs += 1
      used_chars_in_code[code[i]] = used_chars_in_code.get(code[i], 0) + 1

  # Count white pegs (correct color, wrong place)
  for i in range(len(guess)):
    if guess[i] in code and guess[i] != code[i] and used_chars_in_code.get(guess[i], 0) > 0:
      white_pegs += 1
      used_chars_in_code[guess[i]] -= 1

  return black_pegs, white_pegs

# Example usage
# code = "RGBY"
# guess = "GGRB"
# black_pegs, white_pegs = mastermind_clues(code, guess)
# print("Black pegs:", black_pegs)  # Output: Black pegs: 1
# print("White pegs:", white_pegs)  # Output: White pegs: 1
