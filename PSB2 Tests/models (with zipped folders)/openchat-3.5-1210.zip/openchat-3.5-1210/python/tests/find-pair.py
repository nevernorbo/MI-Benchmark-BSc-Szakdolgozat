def find_pair(vector, target):
    seen = {}
    for i, num in enumerate(vector):
        complement = target - num
        if complement in seen:
            return (complement, num)
        seen[num] = i
    return None

# input_vector = [2, 7, 11, 15]
# target = 9
# result = find_pair_with_sum(input_vector, target)
# print(f"The pair that sums to {target} is: {result}")