def middle_character(s):
    length = len(s)
    if length % 2 == 0:
        return s[length // 2 - 1:length // 2 + 1]
    else:
        return s[length // 2]

# input_string = "hello"
# result = middle_characters(input_string)
# print(f"The middle character(s) of the string '{input_string}' is: '{result}'")