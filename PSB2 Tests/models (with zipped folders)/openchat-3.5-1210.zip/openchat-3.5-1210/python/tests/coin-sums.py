def coin_sums(cents):
    coin_values = [25, 10, 5, 1]  # quarters, dimes, nickels, pennies
    coin_count = [0] * len(coin_values)

    for i, value in enumerate(coin_values):
        coin_count[i] = cents // value
        cents %= value

    return coin_count

# input_cents = 99
# output_cents = find_coins(input_cents)
# print(f"Quarters: {output_cents[0]}, Dimes: {output_cents[1]}, Nickels: {output_cents[2]}, Pennies: {output_cents[3]}")