def fuel_cost(vector):
    sum_new = 0
    for num in vector:
        new_num = (num // 3) - 2
        sum_new += new_num
    return sum_new

# input_vector = [10, 20, 30, 40, 50]
# result = sum_new_integers(input_vector)
# print(f"The sum of the new integers is: {result}")