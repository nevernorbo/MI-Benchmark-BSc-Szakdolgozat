def camel_case(kebab_str):
    words = kebab_str.split('-')
    camel_str = words[0].lower()
    for i in range(1, len(words)):
        word = words[i]
        camel_str += word.capitalize()
    return camel_str

# input_str = "camel-case example-test-string"
# output_str = kebab_to_camel(input_str)
# print(output_str)