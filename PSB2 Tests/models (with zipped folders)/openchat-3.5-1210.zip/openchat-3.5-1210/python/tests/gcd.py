def gcd(a, b):
    while b:
        a, b = b, a % b
    return a

# input_a = 60
# input_b = 48
# result = gcd(input_a, input_b)
# print(f"The largest integer that divides both {input_a} and {input_b} evenly is: {result}")