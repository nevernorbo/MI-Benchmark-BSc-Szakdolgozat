def square_digits(n):
    squared_digits = ''
    for digit in str(n):
        squared_digit = str(int(digit) ** 2)
        squared_digits += squared_digit
    return squared_digits

# input_number = 123
# result = square_digits(input_number)
# print(f"The squared digits of the number {input_number} are: {result}")