def indices_of_substring(text, target):
    indices = []
    target_length = len(target)
    for i in range(len(text) - target_length + 1):
        if text[i:i + target_length] == target:
            indices.append(i)
    return indices

# input_text = "abababab"
# input_target = "ab"
# result = find_indices(input_text, input_target)
# print(f"The indices at which the target appears in the text are: {result}")