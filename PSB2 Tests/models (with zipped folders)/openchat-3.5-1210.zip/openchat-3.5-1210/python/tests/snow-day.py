def snow_day(hours, snow_on_ground, snow_fall_rate, melting_rate):
    for _ in range(hours):
        snow_on_ground += snow_fall_rate
        snow_on_ground -= snow_on_ground * melting_rate
    return snow_on_ground

# input_hours = 4
# input_snow_on_ground = 10.0
# input_snow_fall_rate = 1.0
# input_melting_rate = 0.1
# result = snow_on_ground(input_hours, input_snow_on_ground, input_snow_fall_rate, input_melting_rate)
# print(f"The amount of snow on the ground after {input_hours} hours is: {result:.2f}")