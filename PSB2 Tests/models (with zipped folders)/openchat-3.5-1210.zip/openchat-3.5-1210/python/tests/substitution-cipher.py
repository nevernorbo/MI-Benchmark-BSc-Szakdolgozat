def substitution_cipher(cipher1, cipher2, message):
    deciphered_message = ""
    for char in message:
        if char.isalpha():
            char_index = ord(char.lower()) - 97
            deciphered_char = chr((cipher1[char_index] + cipher2[char_index]) % 26 + 97)
            deciphered_message += deciphered_char.upper() if char.isupper() else deciphered_char
        else:
            deciphered_message += char
    return deciphered_message

# input_cipher1 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
# input_cipher2 = "BCDEFGHIJKLMNOPQRSTUVWXYZA"
# input_message = "HeLLo WoRLd!"

# result = decipher_message(input_cipher1, input_cipher2, input_message)
# print(f"The deciphered message is: '{result}'")