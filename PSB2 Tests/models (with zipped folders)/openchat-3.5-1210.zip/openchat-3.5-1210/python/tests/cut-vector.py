def cut_vector(vector):
    min_diff = float('inf')
    cut_position = -1

    for i in range(len(vector) - 1):
        diff = abs(vector[i] - vector[i + 1])
        if diff < min_diff or (diff == min_diff and vector[i] == vector[i + 1]):
            min_diff = diff
            cut_position = i

    left_vector = vector[:cut_position + 1]
    right_vector = vector[cut_position + 1:]

    return cut_position, left_vector, right_vector

# input_vector = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
# cut_position, left_vector, right_vector = find_cut_position(input_vector)
# print(f"Left vector: {left_vector}, Right vector: {right_vector}")