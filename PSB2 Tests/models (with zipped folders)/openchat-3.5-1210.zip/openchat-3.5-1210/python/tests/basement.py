def basement(vec):
    for i, num in enumerate(vec):
        if sum(vec[:i+1]) < 0:
            return i
    return -1  # Return -1 if no negative sum is found