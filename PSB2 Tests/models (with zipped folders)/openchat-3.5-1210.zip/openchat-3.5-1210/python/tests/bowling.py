def bowling(bowling_string):
    score = 0
    frame = 1
    roll = 1
    spare_flag = False
    strike_flag = False

    for char in bowling_string:
        if char == '/':
            roll += 1
            if roll == 2:
                if strike_flag:
                    if spare_flag:
                        score += 10 + 10 + 10 + int(char)
                    else:
                        score += 10 + 10 + int(char)
                else:
                    if spare_flag:
                        score += 10 + int(char)
                    else:
                        score += int(char)
                spare_flag = False
                strike_flag = False
            else:
                if int(char) == 10:
                    strike_flag = True
                    score += 10 + int(bowling_string[roll])
                    roll += 1
                else:
                    score += int(char)
                if spare_flag:
                    score += 10
                spare_flag = False
        elif char == 'X':
            strike_flag = True
            if roll == 2:
                if spare_flag:
                    score += 10 + 10 + 10 + int(char)
                else:
                    score += 10 + 10 + int(char)
                spare_flag = False
                strike_flag = False
            else:
                score += int(char)
                if spare_flag:
                    score += 10
                spare_flag = False
        else:
            score += int(char)
            if spare_flag:
                score += 10
            spare_flag = False

        if roll == 2:
            if frame < 10:
                frame += 1
            roll = 1
            strike_flag = False
            spare_flag = False

    return score