def paired_digits(s):
    sum_digits = 0
    for i in range(len(s) - 1):
        if s[i] == s[i + 1]:
            sum_digits += int(s[i])
    return sum_digits

# input_string = "12223333"
# result = sum_same_digits(input_string)
# print(f"The sum of digits whose following digit is the same in the string '{input_string}' is: {result}")