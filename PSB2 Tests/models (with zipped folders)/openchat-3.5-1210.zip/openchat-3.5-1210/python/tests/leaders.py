def leaders(vector):
    leaders = []
    for i in range(len(vector) - 1, -1, -1):
        is_leader = True
        for j in range(i + 1, len(vector)):
            if vector[j] > vector[i]:
                is_leader = False
                break
        if is_leader:
            leaders.append(vector[i])
    return leaders

# input_vector = [16, 17, 4, 3, 5, 2]
# result = find_leaders(input_vector)
# print(f"The leaders in the vector are: {result}")