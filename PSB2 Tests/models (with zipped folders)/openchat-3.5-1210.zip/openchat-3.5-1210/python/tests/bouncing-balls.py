def bouncing_balls(starting_height, bounciness_index, num_bounces):
    total_distance = 0
    for k in range(num_bounces):
        next_height = starting_height * (bounciness_index) ** (k + 1)
        total_distance += next_height - starting_height
        starting_height = next_height
    return total_distance