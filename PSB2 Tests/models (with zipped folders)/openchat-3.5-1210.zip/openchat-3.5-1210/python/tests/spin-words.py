def spin_words(s):
    words = s.split()
    reversed_words = []

    for word in words:
        if len(word) >= 5:
            reversed_word = word[::-1]
        else:
            reversed_word = word
        reversed_words.append(reversed_word)

    return ' '.join(reversed_words)

# input_string = "This is a test string"
# result = reverse_words(input_string)
# print(f"The resulting string after reversing words that are five or more letters long is: '{result}'")