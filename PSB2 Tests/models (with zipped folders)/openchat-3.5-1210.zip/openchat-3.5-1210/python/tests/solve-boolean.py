def solve_boolean(expression):
    operators = {'T': True, 'F': False}
    stack = []

    for char in expression:
        if char in operators:
            stack.append(operators[char])
        elif char == '|':
            operand1 = stack.pop()
            operand2 = stack.pop()
            stack.append(operand1 | operand2)
        elif char == '&':
            operand1 = stack.pop()
            operand2 = stack.pop()
            stack.append(operand1 & operand2)

    return stack[0]

# input_expression = "T&T|F"
# result = evaluate_boolean_expression(input_expression)
# print(f"The result of the Boolean expression '{input_expression}' is: {result}")