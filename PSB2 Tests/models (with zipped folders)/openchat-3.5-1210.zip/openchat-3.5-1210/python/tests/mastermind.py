def mastermind(code, guess):
    white_pegs = 0
    black_pegs = 0

    for i, color in enumerate(code):
        if color == guess[i]:
            black_pegs += 1
            code = code[:i] + code[i+1:]
            guess = guess[:i] + guess[i+1:]

    for color in code:
        if color in guess:
            white_pegs += 1

    return black_pegs, white_pegs

# input_code = "ABCD"
# input_guess = "BACD"
# result_black, result_white = mastermind_clue(input_code, input_guess)
# print(f"The number of black pegs is: {result_black}, and the number of white pegs is: {result_white}")