def luhn(card_number):
    card_digits = [int(digit) for digit in str(card_number)]
    check_sum = 0
    double_index = 1

    for i in range(len(card_digits) - 1, -1, -1):
        if double_index % 2 == 1:
            check_sum += card_digits[i]
        else:
            doubled = card_digits[i] * 2
            if doubled > 9:
                doubled -= 9
            check_sum += doubled
        double_index += 1

    return check_sum % 10

# input_card_number = 1234567890123456
# result = luhn_algorithm(input_card_number)
# print(f"The result of Luhn's algorithm for the credit card number {input_card_number} is: {result}")