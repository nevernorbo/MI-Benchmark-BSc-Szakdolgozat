def dice_game(peter_sides, colin_sides):
    higher_scores = 0
    total_scores = peter_sides * colin_sides

    for peter in range(1, peter_sides + 1):
        for colin in range(1, colin_sides + 1):
            if peter > colin:
                higher_scores += 1

    probability = higher_scores / total_scores
    return probability

# peter_sides = 6
# colin_sides = 4
# result = probability_higher(peter_sides, colin_sides)
# print(f"Probability that Peter rolls strictly higher than Colin: {result:.4f}")