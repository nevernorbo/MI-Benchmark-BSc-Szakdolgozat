def shopping_list(prices, discounts):
    total_price = 0
    for i in range(len(prices)):
        discounted_price = prices[i] * (1 - discounts[i] / 100)
        total_price += discounted_price
    return total_price

# input_prices = [10.50, 5.99, 20.00, 7.50]
# input_discounts = [10, 20, 5, 15]
# result = calculate_total_price(input_prices, input_discounts)
# print(f"The total price of the shopping trip after applying the discounts is: {result:.2f}")