def bowling(round_string):
    score = 0
    frame = 1
    bowl_index = 0

    while frame <= 10:
        if round_string[bowl_index] == 'X':  # Strike
            score += 10 + get_strike_bonus(round_string, bowl_index)
            bowl_index += 1
        elif round_string[bowl_index] == '/':  # Spare
            score += 10 + get_spare_bonus(round_string, bowl_index)
            bowl_index += 2
        else:  # Open frame
            score += get_bowl_score(round_string[bowl_index])
            score += get_bowl_score(round_string[bowl_index + 1])
            bowl_index += 2

        frame += 1

    return score


def get_strike_bonus(round_string, bowl_index):
    bonus = 0
    if bowl_index + 2 < len(round_string):
        bonus += get_bowl_score(round_string[bowl_index + 1])
        if round_string[bowl_index + 1] == 'X':
            bonus += get_bowl_score(round_string[bowl_index + 2])
    return bonus


def get_spare_bonus(round_string, bowl_index):
    bonus = 0
    if bowl_index + 2 < len(round_string):
        bonus += get_bowl_score(round_string[bowl_index + 2])
    return bonus


def get_bowl_score(bowl):
    if bowl == 'X' or bowl == '/':
        return 10
    elif bowl == '-':
        return 0
    else:
        return int(bowl)


# # Example usage
# round_string = "X7/9-X-88/-6XXX81"
# score = calculate_bowling_score(round_string)
# print(score)  # Output: 167