def leaders(nums):
    leaders = []
    max_num = float('-inf')
    for i in range(len(nums)-1, -1, -1):
        if nums[i] >= max_num:
            leaders.append(nums[i])
            max_num = nums[i]
    leaders.reverse()
    return leaders

# # Example usage
# nums = [16, 17, 4, 3, 5, 2]
# result = find_leaders(nums)
# print("Leaders in the vector:", result)