def shopping_list(prices, discounts):
    total_price = 0
    
    for price, discount in zip(prices, discounts):
        discounted_price = price - (price * discount / 100)
        total_price += discounted_price
    
    return total_price