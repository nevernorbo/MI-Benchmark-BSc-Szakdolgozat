def coin_sums(cents):
    quarters = cents // 25
    cents %= 25

    dimes = cents // 10
    cents %= 10

    nickels = cents // 5
    cents %= 5

    pennies = cents

    return quarters, dimes, nickels, pennies

# # Example usage
# cents = 87
# quarters, dimes, nickels, pennies = find_min_coins(cents)
# print("Quarters:", quarters)
# print("Dimes:", dimes)
# print("Nickels:", nickels)
# print("Pennies:", pennies)