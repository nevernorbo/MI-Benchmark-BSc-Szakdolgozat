def dice_game(n, m):
    total_outcomes = n * m
    count = 0

    for peter_roll in range(1, n+1):
        for colin_roll in range(1, m+1):
            if peter_roll > colin_roll:
                count += 1

    probability = count / total_outcomes
    return probability