def camel_case(string):
    words = string.split("-")
    camel_case = words[0]
    
    for word in words[1:]:
        camel_case += word.capitalize()
    
    return camel_case

# # Example usage
# kebab_string = "camel-case example-test-string"
# camel_string = kebab_to_camel(kebab_string)
# print(camel_string)  # Output: "camelCase exampleTestString"