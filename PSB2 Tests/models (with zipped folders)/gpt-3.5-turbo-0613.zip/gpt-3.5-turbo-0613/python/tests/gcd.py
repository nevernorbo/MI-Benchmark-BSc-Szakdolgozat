def find_gcd(a, b):
    while b:
        a, b = b, a % b
    return a

def gcd(num1, num2):
    gcd = find_gcd(num1, num2)
    return gcd

# # Example usage
# num1 = 12
# num2 = 18
# result = largest_common_divisor(num1, num2)
# print("The largest common divisor of", num1, "and", num2, "is:", result)