def mastermind(code, guess):
    code_count = [0] * 6
    guess_count = [0] * 6
    black_pegs = 0
    white_pegs = 0

    # Count the occurrences of each character in code and guess
    for i in range(4):
        code_count[int(code[i]) - 1] += 1
        guess_count[int(guess[i]) - 1] += 1

    # Calculate black pegs (correct color, correct place)
    for i in range(4):
        if code[i] == guess[i]:
            black_pegs += 1
            code_count[int(code[i]) - 1] -= 1
            guess_count[int(guess[i]) - 1] -= 1

    # Calculate white pegs (correct color, wrong place)
    for i in range(6):
        white_pegs += min(code_count[i], guess_count[i])

    return white_pegs, black_pegs

# # Example usage
# code = "1234"
# guess = "1562"
# white_pegs, black_pegs = calculate_pegs(code, guess)
# print("White pegs:", white_pegs)
# print("Black pegs:", black_pegs)