import math

def vector_distance(vector1, vector2):
    if len(vector1) != len(vector2):
        raise ValueError("Vectors must have the same number of dimensions")
    
    squared_diff_sum = 0
    for i in range(len(vector1)):
        squared_diff_sum += (vector1[i] - vector2[i]) ** 2
    
    distance = math.sqrt(squared_diff_sum)
    return distance