def luhn(digits):
    # Step 1: Double every other digit starting from the second digit
    for i in range(len(digits) - 2, -1, -2):
        digits[i] *= 2
        # Step 2: Subtract 9 if the result is greater than 9
        if digits[i] > 9:
            digits[i] -= 9

    # Step 3: Calculate the sum of all the digits
    total_sum = sum(digits)

    # Step 4: Check if the sum is divisible by 10
    if total_sum % 10 == 0:
        return True  # Valid credit card number
    else:
        return False  # Invalid credit card number

# # Example usage
# credit_card_number = [4, 5, 1, 2, 3, 4, 5, 6, 7, 8, 9, 1, 2, 3, 4, 5]
# result = luhn_algorithm(credit_card_number)
# print("Is the credit card number valid?", result)