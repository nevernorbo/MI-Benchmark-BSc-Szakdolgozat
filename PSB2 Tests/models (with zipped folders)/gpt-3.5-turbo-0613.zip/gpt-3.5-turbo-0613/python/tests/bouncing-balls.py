def bouncing_balls(starting_height, bounciness_index, num_bounces):
    total_distance = 0
    current_height = starting_height

    for _ in range(num_bounces):
        total_distance += current_height  # Add the current height to the total distance
        current_height *= bounciness_index  # Calculate the height after each bounce

    total_distance += current_height  # Add the final height to the total distance

    return total_distance

# # Example usage
# starting_height = 10
# bounciness_index = 0.6
# num_bounces = 3

# distance = calculate_total_distance(starting_height, bounciness_index, num_bounces)
# print(distance)  # Output: 19.6