def basement(nums):
    total_sum = 0
    for i in range(len(nums)):
        total_sum += nums[i]
        if total_sum < 0:
            return i
    return -1  # If no negative sum is found

# # Example usage
# nums = [1, 2, -3, 4, 5, -6]
# index = first_negative_sum_index(nums)
# print(index)  # Output: 2