def solve_boolean(expression):
    result = eval(expression)
    return bool(result)