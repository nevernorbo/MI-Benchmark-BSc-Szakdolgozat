def fuel_cost(vector):
    total_sum = 0

    for num in vector:
        new_num = (num // 3) - 2
        total_sum += new_num

    return total_sum