def indices_of_substring(text, target):
    indices = []
    start_index = 0
    while True:
        index = text.find(target, start_index)
        if index == -1:
            break
        indices.append(index)
        start_index = index + 1
    return indices

# # Example usage
# text = "abababab"
# target = "aba"
# result = find_indices(text, target)
# print("Indices where the target appears:", result)