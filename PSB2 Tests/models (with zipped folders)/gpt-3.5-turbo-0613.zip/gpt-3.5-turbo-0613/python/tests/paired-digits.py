def paired_digits(s):
    length = len(s)
    total = 0
    
    for i in range(length - 1):
        if s[i] == s[i + 1]:
            total += int(s[i])
    
    return total