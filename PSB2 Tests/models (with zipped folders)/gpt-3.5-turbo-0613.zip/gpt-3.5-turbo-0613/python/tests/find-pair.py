def find_pair(vector, target):
    seen = {}
    
    for num in vector:
        complement = target - num
        
        if complement in seen:
            return [complement, num]
        
        seen[num] = True
    
    return None