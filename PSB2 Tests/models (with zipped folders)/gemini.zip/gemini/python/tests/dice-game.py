def dice_game(n, m):
  """
  This function calculates the probability that Peter rolls a strictly higher number than Colin, 
  given the number of sides on their dice (n for Peter, m for Colin).

  Args:
      n: The number of sides on Peter's die.
      m: The number of sides on Colin's die.

  Returns:
      The probability that Peter rolls a strictly higher number than Colin.
  """
  # Favorable outcomes: all outcomes where Peter rolls higher (n-1)
  favorable_outcomes = n - 1

  # Total possible outcomes: n x m (Peter's roll x Colin's roll)
  total_outcomes = n * m

  # Probability is favorable outcomes divided by total outcomes
  probability = favorable_outcomes / total_outcomes
  return probability

# # Example usage
# n = 6  # Peter's die has 6 sides
# m = 4  # Colin's die has 4 sides
# probability = probability_of_peter_wins(n, m)
# print(f"Probability of Peter winning: {probability}")  # Output: Probability of Peter winning: 0.75
