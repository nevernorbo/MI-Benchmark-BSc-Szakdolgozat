def fuel_cost(nums):
  """
  This function takes a vector of positive integers, divides each by 3, rounds down, 
  subtracts 2, and returns the sum of the new integers.

  Args:
      nums: A list of positive integers.

  Returns:
      The sum of the modified integers in the vector.
  """
  modified_list = [int((num // 3) - 2) for num in nums]
  return sum(modified_list)

# # Example usage
# nums = [5, 1, 4]
# modified_sum_result = modified_sum(nums)
# print(modified_sum_result)  # Output: -4
