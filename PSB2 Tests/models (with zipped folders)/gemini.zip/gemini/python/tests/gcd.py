def gcd(a, b):
  """
  This function calculates the greatest common divisor (GCD) of two integers a and b.

  Args:
      a: The first integer.
      b: The second integer.

  Returns:
      The greatest common divisor of a and b.
  """
  while b != 0:
    remainder = a % b
    a = b
    b = remainder
  return a

# # Example usage
# num1 = 18
# num2 = 12
# result = gcd(num1, num2)
# print(result)  # Output: 6
