def coin_sums(cents):
  """
  This function calculates the fewest number of US coins (pennies, nickles, dimes, quarters) 
  needed to make a given amount in cents.

  Args:
      cents: An integer representing the amount in cents.

  Returns:
      A dictionary containing the number of each type of coin (pennies, nickles, dimes, quarters).
  """
  coins = {"quarters": 0, "dimes": 0, "nickels": 0, "pennies": 0}

  # Use highest denomination coins first
  while cents >= 25:
    coins["quarters"] += 1
    cents -= 25
  while cents >= 10:
    coins["dimes"] += 1
    cents -= 10
  while cents >= 5:
    coins["nickels"] += 1
    cents -= 5
  # Remaining amount will be in pennies
  coins["pennies"] = cents

  return coins

# # Example usage
# cents = 87
# coin_breakdown = get_coin_breakdown(cents)
# print(coin_breakdown)  # Output: {'quarters': 3, 'dimes': 2, 'nickels': 0, 'pennies': 2}
