def leaders(nums):
  """
  This function finds all leaders in a vector of positive integers. 
  A leader is defined as a number that is greater than or equal to all the numbers to its right.

  Args:
      nums: A list of positive integers.

  Returns:
      A list containing all leaders in the vector.
  """
  leaders = []
  # Traverse from right to left
  for i in range(len(nums) - 1, -1, -1):
    # Check if the current element is greater than all elements to its right
    is_leader = True
    for j in range(i + 1, len(nums)):
      if nums[i] < nums[j]:
        is_leader = False
        break
    if is_leader:
      leaders.append(nums[i])

  # Since the rightmost element is always a leader, prepend it to the list
  leaders.insert(0, nums[-1])
  return leaders

# # Example usage
# nums = [6, 7, 4, 3, 5]
# result = find_leaders(nums)
# print(result)  # Output: [7, 6, 5]
