def basement(nums):
  """
  This function finds the first index in a vector where the sum of all integers 
  from the start of the vector to that index (inclusive) is negative.

  Args:
      nums: A list of integers.

  Returns:
      The first index where the sum is negative, or len(nums) if no such index exists.
  """
  current_sum = 0
  for i, num in enumerate(nums):
    current_sum += num
    if current_sum < 0:
      return i
  return len(nums)

# # Example usage
# nums = [1, 2, -3, 4, -1]
# result = find_first_negative_sum(nums)
# print(result)  # Output: 2
