def bowling(frame_string):
  """
  This function calculates the score of a 10-frame bowling round represented by a string.

  Args:
      frame_string: A string representing the pins knocked down in each frame,
                     using characters like 'X' for strike, '-' for spare, and numbers for pins.

  Returns:
      The total score of the bowling round.
  """
  frames = frame_string.split(' ')
  total_score = 0
  frame_number = 0

  for frame in frames:
    # Handle strike (marked as 'X')
    if frame == 'X':
      total_score += 10
      # Add the pins knocked down in the next two throws (if available)
      if frame_number < 9:
        total_score += int(frames[frame_number + 1][0]) if frames[frame_number + 1] != 'X' else 10
        if frame_number < 8 and frames[frame_number + 2] != 'X':
          total_score += int(frames[frame_number + 2][0])

    # Handle spare (marked as '-')
    elif frame == '-':
      total_score += 10
      # Add the pins knocked down in the next throw
      total_score += int(frames[frame_number + 1][0])

    # Handle regular frames (numbers represent pins knocked down)
    else:
      total_score += sum(int(char) for char in frame)

    frame_number += 1

  return total_score

# # Example usage
# frame_string = "X 7 3 9 0 1 6 4 X 2 4"
# score = calculate_bowling_score(frame_string)
# print(f"Total score: {score}")  # Output: Total score: 82
