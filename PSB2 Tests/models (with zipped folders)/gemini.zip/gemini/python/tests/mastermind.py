def mastermind(code, guess):
  """
  This function takes a Mastermind code and guess as input and returns the number of black and white pegs.

  Args:
      code: The Mastermind code string.
      guess: The Mastermind guess string.

  Returns:
      A tuple containing the number of black pegs and white pegs.
  """
  black_pegs = 0
  white_pegs = 0
  code_dict = {}
  guess_dict = {}
  
  # Create a dictionary to store the frequency of each character in the code
  for char in code:
    if char in code_dict:
      code_dict[char] += 1
    else:
      code_dict[char] = 1

  # Create a dictionary to store the frequency of each character in the guess
  for char in guess:
    if char in guess_dict:
      guess_dict[char] = guess_dict.get(char, 0) + 1
    else:
      guess_dict[char] = 1

  # Count the number of black pegs (correct color, correct place)
  for i in range(len(code)):
    if code[i] == guess[i]:
      black_pegs += 1
      code_dict[code[i]] -= 1
      guess_dict[guess[i]] -= 1

  # Count the number of white pegs (correct color, wrong place)
  for char, count in guess_dict.items():
    if char in code_dict and code_dict[char] > 0 and count > 0:
      white_pegs += min(count, code_dict[char])

  return black_pegs, white_pegs

# # Example usage
# code = "RGBY"
# guess = "GGRB"
# black_pegs, white_pegs = mastermind(code, guess)
# print(f"Black pegs: {black_pegs}, White pegs: {white_pegs}")
