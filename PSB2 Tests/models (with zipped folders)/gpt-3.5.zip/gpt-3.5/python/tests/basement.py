def basement(nums):
    """
    Find the index of the first element such that the sum of all elements up to that index is negative.

    Args:
    nums (list of int): The input list of integers.

    Returns:
    int: The index of the first element where the sum becomes negative, or -1 if no such index exists.
    """
    current_sum = 0
    for i, num in enumerate(nums):
        current_sum += num
        if current_sum < 0:
            return i
    return -1  # If no such index exists


# # Example usage:
# vector = [1, 2, 3, -4, 5, 6]
# print(first_negative_sum_index(vector))  # Output will be 3
