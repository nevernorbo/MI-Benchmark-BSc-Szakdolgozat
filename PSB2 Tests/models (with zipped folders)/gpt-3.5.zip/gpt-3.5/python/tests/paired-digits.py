def paired_digits(digits):
    """
    Return the sum of digits whose following digit is the same.

    Args:
    digits (str): The input string of digits.

    Returns:
    int: The sum of digits whose following digit is the same.
    """
    total_sum = 0
    length = len(digits)
    for i in range(length - 1):  # Iterate up to the second last digit
        if digits[i] == digits[i + 1]:
            total_sum += int(digits[i])
    return total_sum


# # Example usage:
# digits = "112345556"
# result = sum_following_duplicates(digits)
# print("Sum of digits whose following digit is the same:", result)
