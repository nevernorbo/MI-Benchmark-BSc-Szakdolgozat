def middle_character(s):
    """
    Return the middle character(s) of a string.

    Args:
    s (str): The input string.

    Returns:
    str: The middle character(s) of the string.
    """
    length = len(s)
    middle_index = length // 2

    if length % 2 == 1:  # Odd length
        return s[middle_index]
    else:  # Even length
        return s[middle_index - 1: middle_index + 1]


# # Example usage:
# s1 = "abcde"
# s2 = "abcdef"
# print("Middle character(s) of", s1, ":", middle_characters(s1))
# print("Middle character(s) of", s2, ":", middle_characters(s2))
