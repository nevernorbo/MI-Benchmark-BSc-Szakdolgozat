def bowling(bowls):
    """
    Calculate the score of a round of 10-pin bowling.

    Args:
    bowls (str): String representing the individual bowls in a round of bowling.

    Returns:
    int: The total score of the round.
    """
    score = 0
    frame = 1
    bowl_index = 0
    while frame <= 10:
        if bowls[bowl_index] == 'X':  # Strike
            score += 10
            score += calculate_strike_bonus(bowls, bowl_index)
            bowl_index += 1
        elif bowls[bowl_index + 1] == '/':  # Spare
            score += 10
            score += calculate_spare_bonus(bowls, bowl_index)
            bowl_index += 2
        else:
            score += int(bowls[bowl_index]) + int(bowls[bowl_index + 1])
            bowl_index += 2
        frame += 1
    return score


def calculate_strike_bonus(bowls, bowl_index):
    """
    Calculate the bonus score for a strike.

    Args:
    bowls (str): String representing the individual bowls in a round of bowling.
    bowl_index (int): Index of the bowl where the strike occurred.

    Returns:
    int: The bonus score for the strike.
    """
    bonus = 0
    next_two_bowls = bowls[bowl_index + 1: bowl_index + 3]
    for bowl in next_two_bowls:
        if bowl == '/':  # Spare after the strike
            bonus += 10 - int(bowls[bowl_index + 1])
        else:
            bonus += int(bowl)
    return bonus


def calculate_spare_bonus(bowls, bowl_index):
    """
    Calculate the bonus score for a spare.

    Args:
    bowls (str): String representing the individual bowls in a round of bowling.
    bowl_index (int): Index of the bowl where the spare occurred.

    Returns:
    int: The bonus score for the spare.
    """
    return int(bowls[bowl_index + 2]) - int(bowls[bowl_index + 1])


# # Example usage:
# bowls = "X7/9-X-88/-6XXX81"
# print("Total score:", calculate_bowling_score(bowls))  # Output will be the total score of the round
