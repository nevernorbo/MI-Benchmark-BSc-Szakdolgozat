def coin_sums(cents):
    """
    Find the fewest number of US coins needed to make the given amount of cents.

    Args:
    cents (int): The amount in cents.

    Returns:
    tuple: A tuple containing the number of each type of coin (pennies, nickels, dimes, quarters).
    """
    quarters = cents // 25
    cents %= 25
    dimes = cents // 10
    cents %= 10
    nickels = cents // 5
    cents %= 5
    pennies = cents
    return pennies, nickels, dimes, quarters


# # Example usage:
# cents = 87
# pennies, nickels, dimes, quarters = min_coins(cents)
# print("Pennies:", pennies)
# print("Nickels:", nickels)
# print("Dimes:", dimes)
# print("Quarters:", quarters)
