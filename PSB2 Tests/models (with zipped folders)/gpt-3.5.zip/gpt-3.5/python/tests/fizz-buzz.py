def fizz_buzz(x):
    """
    Return "Fizz" if x is divisible by 3, "Buzz" if x is divisible by 5,
    "FizzBuzz" if x is divisible by both 3 and 5, and a string version of x otherwise.

    Args:
    x (int): The input integer.

    Returns:
    str: The corresponding string as per the conditions.
    """
    if x % 3 == 0 and x % 5 == 0:
        return "FizzBuzz"
    elif x % 3 == 0:
        return "Fizz"
    elif x % 5 == 0:
        return "Buzz"
    else:
        return str(x)


# # Example usage:
# for i in range(1, 16):
#     print(fizz_buzz(i))
