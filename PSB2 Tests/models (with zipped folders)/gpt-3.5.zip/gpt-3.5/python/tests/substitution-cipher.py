def substitution_cipher(cipher1, cipher2, message):
    """
    Decipher a message using the given cipher.

    Args:
    cipher1 (str): The first string representing the cipher.
    cipher2 (str): The second string representing the cipher.
    message (str): The message to be deciphered.

    Returns:
    str: The deciphered message.
    """
    deciphered_message = ''
    for char in message:
        index = cipher2.find(char)
        deciphered_message += cipher1[index] if index != -1 else char
    return deciphered_message


# # Example usage:
# cipher1 = "abcdefghijklmnopqrstuvwxyz"
# cipher2 = "zyxwvutsrqponmlkjihgfedcba"
# message = "gvhg lu gsv xlfmwh"
# deciphered_message = decipher_message(cipher1, cipher2, message)
# print("Deciphered message:", deciphered_message)
