import math

def gcd(num1, num2):
    """
    Return the largest integer that divides each of the given integers evenly.

    Args:
    num1 (int): The first integer.
    num2 (int): The second integer.

    Returns:
    int: The largest common divisor of the two integers.
    """
    return math.gcd(num1, num2)


# # Example usage:
# num1 = 24
# num2 = 36
# result = largest_common_divisor(num1, num2)
# print("Largest integer that divides both", num1, "and", num2, "evenly:", result)
