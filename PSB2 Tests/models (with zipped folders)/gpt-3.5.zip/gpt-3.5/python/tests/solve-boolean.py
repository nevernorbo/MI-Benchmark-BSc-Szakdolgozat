def solve_boolean(expression):
    """
    Evaluate a Boolean expression represented as a string.

    Args:
    expression (str): The Boolean expression consisting of T, F, |, and &.

    Returns:
    bool: The resulting Boolean value after evaluation.
    """
    stack = []
    for char in expression:
        if char == 'T':
            stack.append(True)
        elif char == 'F':
            stack.append(False)
        elif char == '|':
            operand2 = stack.pop()
            operand1 = stack.pop()
            stack.append(operand1 or operand2)
        elif char == '&':
            operand2 = stack.pop()
            operand1 = stack.pop()
            stack.append(operand1 and operand2)
    return stack.pop()


# # Example usage:
# expression = "T|F&F"
# result = evaluate_boolean_expression(expression)
# print("Result of Boolean expression", expression, ":", result)
