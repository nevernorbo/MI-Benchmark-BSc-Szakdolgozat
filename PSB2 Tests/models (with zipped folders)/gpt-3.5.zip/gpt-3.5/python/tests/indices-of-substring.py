def indices_of_substring(text, target):
    """
    Find the indices at which the target appears in the text.

    Args:
    text (str): The input text string.
    target (str): The target string to search for.

    Returns:
    list of int: A list of indices at which the target appears in the text.
    """
    indices = []
    index = 0
    while index < len(text):
        index = text.find(target, index)
        if index == -1:
            break
        indices.append(index)
        index += 1
    return indices


# # Example usage:
# text = "ababababa"
# target = "aba"
# result = find_indices(text, target)
# print("Indices where", target, "appears in the text:", result)
