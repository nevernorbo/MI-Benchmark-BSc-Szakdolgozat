def camel_case(kebab_case_str):
    """
    Convert a string from kebab-case to camelCase.

    Args:
    kebab_case_str (str): The input string in kebab-case.

    Returns:
    str: The converted string in camelCase.
    """
    words = kebab_case_str.split('-')
    camel_case_str = words[0] + ''.join(word.capitalize() for word in words[1:])
    return camel_case_str


# # Example usage:
# kebab_str = "camel-case example-test-string"
# camel_str = kebab_to_camel(kebab_str)
# print(camel_str)  # Output: camelCase exampleTestString
