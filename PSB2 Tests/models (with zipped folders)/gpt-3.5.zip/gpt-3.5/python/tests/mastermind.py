def mastermind(code, guess):
    """
    Calculate the number of white and black pegs (clues) for a Mastermind game.

    Args:
    code (str): The Mastermind code.
    guess (str): The guess made by the player.

    Returns:
    tuple: A tuple containing the number of white pegs (correct color, wrong place)
           and black pegs (correct color, correct place).
    """
    black_pegs = sum(c == g for c, g in zip(code, guess))  # Count correct color, correct place (black pegs)
    
    code_counts = {}
    guess_counts = {}
    for c, g in zip(code, guess):
        code_counts[c] = code_counts.get(c, 0) + 1
        guess_counts[g] = guess_counts.get(g, 0) + 1
    
    white_pegs = sum(min(code_counts.get(char, 0), guess_counts.get(char, 0)) for char in set(code))
    white_pegs -= black_pegs  # Remove black pegs from white pegs count
    
    return white_pegs, black_pegs


# # Example usage:
# code = "ABCD"
# guess = "ADCB"
# white_pegs, black_pegs = mastermind_clues(code, guess)
# print("White pegs:", white_pegs)
# print("Black pegs:", black_pegs)
