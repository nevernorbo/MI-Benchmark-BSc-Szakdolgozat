import math

def vector_distance(vector1, vector2):
    """
    Calculate the Euclidean distance between two n-dimensional vectors.

    Args:
    vector1 (list of float): The first n-dimensional vector.
    vector2 (list of float): The second n-dimensional vector.

    Returns:
    float: The Euclidean distance between the two vectors.
    """
    if len(vector1) != len(vector2):
        raise ValueError("Vectors must have the same number of dimensions")

    squared_distances = [(v1 - v2) ** 2 for v1, v2 in zip(vector1, vector2)]
    distance = math.sqrt(sum(squared_distances))
    return distance


# # Example usage:
# vector1 = [1.0, 2.0, 3.0]
# vector2 = [4.0, 5.0, 6.0]
# distance = euclidean_distance(vector1, vector2)
# print("Euclidean distance between the two vectors:", distance)
