def shopping_list(prices, discounts):
    """
    Calculate the total price of the shopping trip after applying discounts to each item.

    Args:
    prices (list of float): The vector of prices of shopping goods.
    discounts (list of float): The vector of percent discounts for each shopping good.

    Returns:
    float: The total price of the shopping trip after applying discounts.
    """
    total_price = sum(price * (1 - discount / 100) for price, discount in zip(prices, discounts))
    return total_price


# # Example usage:
# prices = [10.0, 20.0, 30.0]
# discounts = [10.0, 15.0, 20.0]
# total_price = total_shopping_price(prices, discounts)
# print("Total price of the shopping trip after discounts:", total_price)
