def dice_game(n, m):
    """
    Calculate the probability that Peter rolls strictly higher than Colin.

    Args:
    n (int): Number of sides on Peter's die.
    m (int): Number of sides on Colin's die.

    Returns:
    float: The probability that Peter rolls strictly higher than Colin.
    """
    total_outcomes = n * m
    favorable_outcomes = sum(i - 1 for i in range(1, n))
    probability = favorable_outcomes / total_outcomes
    return probability


# # Example usage:
# n = 6  # Peter's die has 6 sides
# m = 4  # Colin's die has 4 sides
# print("Probability:", probability_peter_higher(n, m))
