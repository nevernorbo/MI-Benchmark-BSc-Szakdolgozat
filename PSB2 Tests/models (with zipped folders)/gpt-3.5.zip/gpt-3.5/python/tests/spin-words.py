def spin_words(sentence):
    """
    Reverse all words that are five or more letters long in a sentence.

    Args:
    sentence (str): The input string containing one or more words.

    Returns:
    str: The resulting string after reversing long words.
    """
    words = sentence.split()
    for i in range(len(words)):
        if len(words[i]) >= 5:
            words[i] = words[i][::-1]  # Reverse the word
    return ' '.join(words)


# # Example usage:
# sentence = "Python is a great programming language"
# result = reverse_long_words(sentence)
# print("Resulting string after reversing long words:", result)
