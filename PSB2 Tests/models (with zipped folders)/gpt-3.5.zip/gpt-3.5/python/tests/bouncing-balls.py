def bouncing_balls(start_height, bounce_height, num_bounces):
    """
    Calculate the total distance traveled by a ball across a given number of bounces.

    Args:
    start_height (float): The starting height from which the ball is dropped.
    bounce_height (float): The height after the first bounce.
    num_bounces (int): The number of bounces the ball makes.

    Returns:
    float: The total distance traveled by the ball.
    """
    bounciness_index = bounce_height / start_height
    total_distance = start_height  # The ball travels the initial height when dropped
    for _ in range(num_bounces):
        total_distance += 2 * bounce_height  # Each bounce adds the bounce height twice (up and down)
        bounce_height *= bounciness_index  # The height of the bounce decreases with each bounce
    return total_distance


# # Example usage:
# start_height = 10  # meters
# bounce_height = 6  # meters
# num_bounces = 3
# total_distance = calculate_total_distance(start_height, bounce_height, num_bounces)
# print("Total distance traveled by the ball:", total_distance, "meters")
