def square_digits(number):
    """
    Square each digit of a positive integer and concatenate the squares into a string.

    Args:
    number (int): The input positive integer.

    Returns:
    str: The concatenated string of squares of digits.
    """
    result = ''
    for digit in str(number):
        squared_digit = int(digit) ** 2
        result += str(squared_digit)
    return result


# # Example usage:
# number = 12345
# result = square_and_concatenate_digits(number)
# print("Concatenated string of squares of digits:", result)
