def twitter(tweet):
    """
    Validate a tweet based on Twitter's original character requirements.

    Args:
    tweet (str): The input string representing a tweet.

    Returns:
    str: A validation message based on the tweet's length.
    """
    if not tweet:
        return "You didn’t type anything"
    elif len(tweet) > 140:
        return "Too many characters"
    else:
        return f"Your tweet has {len(tweet)} characters"


# # Example usage:
# tweet1 = "This is a valid tweet."
# tweet2 = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec euismod ultricies massa, nec eleifend sapien lobortis ut. Fusce suscipit placerat odio, at sagittis justo."
# tweet3 = ""

# print(validate_tweet(tweet1))
# print(validate_tweet(tweet2))
# print(validate_tweet(tweet3))
