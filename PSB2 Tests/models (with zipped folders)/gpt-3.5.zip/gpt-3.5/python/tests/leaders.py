def leaders(vector):
    """
    Find the leaders in the vector.

    Args:
    vector (list of int): The input vector of positive integers.

    Returns:
    list of int: A list containing the leaders in the vector.
    """
    leaders = []
    max_right = float('-inf')  # Initialize maximum value encountered so far

    # Iterate the vector from right to left
    for num in reversed(vector):
        if num >= max_right:
            leaders.append(num)
            max_right = num

    return list(reversed(leaders))  # Reverse the list to maintain the original order


# # Example usage:
# vector = [16, 17, 4, 3, 5, 2]
# result = find_leaders(vector)
# print("Leaders in the vector:", result)
