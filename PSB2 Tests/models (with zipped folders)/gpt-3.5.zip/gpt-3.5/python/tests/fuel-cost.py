def fuel_cost(vector):
    """
    Calculate the sum of integers obtained by dividing each element of the vector by 3, rounding down, and subtracting 2.

    Args:
    vector (list of int): The input vector of positive integers.

    Returns:
    int: The sum of the new integers obtained.
    """
    new_integers = [(num // 3) - 2 for num in vector]
    return sum(new_integers)


# # Example usage:
# vector = [9, 12, 15, 18]
# result = calculate_sum(vector)
# print("Sum of new integers:", result)
