def snow_day(hours, snow_on_ground, snowfall_rate, melting_rate):
    """
    Calculate the amount of snow on the ground after a given number of hours.

    Args:
    hours (int): The number of hours.
    snow_on_ground (float): The initial amount of snow on the ground.
    snowfall_rate (float): The rate of snowfall per hour.
    melting_rate (float): The proportion of snow melting per hour.

    Returns:
    float: The amount of snow on the ground after the given number of hours.
    """
    for _ in range(hours):
        snow_on_ground += snowfall_rate  # Add snowfall
        snow_on_ground *= (1 - melting_rate)  # Melt snow
    return snow_on_ground


# # Example usage:
# hours = 5
# initial_snow = 10.0
# snowfall_rate = 2.0
# melting_rate = 0.1
# final_snow = snow_on_ground(hours, initial_snow, snowfall_rate, melting_rate)
# print("Amount of snow on the ground after", hours, "hours:", final_snow)
