def cut_vector(vector):
    """
    Find the spot where cutting the vector results in two subvectors with either equal sums or the smallest possible difference.

    Args:
    vector (list of int): The input vector of positive integers.

    Returns:
    tuple: A tuple containing the two resulting subvectors.
    """
    total_sum = sum(vector)
    left_sum = 0
    min_diff = float('inf')
    cut_spot = 0

    for i, num in enumerate(vector):
        left_sum += num
        right_sum = total_sum - left_sum
        current_diff = abs(left_sum - right_sum)
        
        if current_diff < min_diff or (current_diff == min_diff and abs(len(vector) // 2 - i) < abs(len(vector) // 2 - cut_spot)):
            min_diff = current_diff
            cut_spot = i

    return vector[:cut_spot + 1], vector[cut_spot + 1:]


# # Example usage:
# vector = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
# subvector1, subvector2 = find_cut_spot(vector)
# print("Subvector 1:", subvector1)
# print("Subvector 2:", subvector2)
