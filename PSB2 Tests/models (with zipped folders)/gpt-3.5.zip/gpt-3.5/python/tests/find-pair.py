def find_pair(nums, target):
    """
    Find two elements in the vector that sum up to the target integer.

    Args:
    nums (list of int): The input vector of integers.
    target (int): The target sum.

    Returns:
    tuple or None: A tuple containing the indices of the two elements if found, otherwise None.
    """
    num_dict = {}  # Dictionary to store numbers and their indices

    for i, num in enumerate(nums):
        complement = target - num
        if complement in num_dict:
            return num_dict[complement], i
        num_dict[num] = i

    return None


# # Example usage:
# nums = [2, 7, 11, 15]
# target = 9
# result = two_sum(nums, target)
# if result is not None:
#     index1, index2 = result
#     print("Indices of the two elements:", index1, index2)
#     print("The two elements:", nums[index1], nums[index2])
# else:
#     print("No such pair found.")
