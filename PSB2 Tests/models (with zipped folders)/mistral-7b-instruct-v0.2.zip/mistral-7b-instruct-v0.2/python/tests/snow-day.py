def snow_day(hours, snow_on_ground_initial, snow_fall_rate, snow_melting_proportion):
    total_snow = snow_on_ground_initial
    for i in range(int(hours)):
        snow_fall = snow_fall_rate
        snow_melt = total_snow * snow_melting_proportion
        total_snow += snow_fall - snow_melt
    return total_snow