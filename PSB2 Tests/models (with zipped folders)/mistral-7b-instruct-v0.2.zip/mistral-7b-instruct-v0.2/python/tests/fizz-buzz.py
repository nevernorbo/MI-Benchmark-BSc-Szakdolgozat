def fizz_buzz(x):
    if x % 3 == 0:
        return "Fizz" if x % 5 != 0 else "FizzBuzz"
    elif x % 5 == 0:
        return "Buzz"
    else:
        return str(x)

# # Test the function
# for x in [1, 3, 5, 15, 7, 10, 14, 18]:
#     print(f"{x}: {fizz_buzz(x)}")