def substitution_cipher(cipher, message):
    deciphered_message = ""
    for char in message:
        deciphered_message += cipher[ord(char) % len(cipher)]
    return deciphered_message

# # Define the cipher strings
# cipher1 = "atbcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
# cipher2 = "zpyxwvutsrqponmlkjihgfedcbaZPYXWVUTSRQPONMLKJIHGFEDCBA"

# # Define the message to decipher
# message = "KhoorZruog"

# # Decipher the message using the given cipher
# deciphered_message = apply_cipher(cipher2, message)

# # Print the deciphered message
# print(deciphered_message)