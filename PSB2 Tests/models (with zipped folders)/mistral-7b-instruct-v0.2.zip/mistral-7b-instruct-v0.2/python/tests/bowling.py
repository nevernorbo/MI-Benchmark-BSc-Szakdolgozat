def bowling(bowling_round):
    # Initialize variables to keep track of the score and current frame
    score = 0
    frame_num = 1
    current_roll = 0

    # Iterate over each character in the input string
    for roll in bowling_round:
        # If it's the start of a new frame
        if current_roll == 0:
            # If it's a strike, add 10 to the score and move on to the next frame
            if roll == 'X':
                score += 10
                current_roll += 1
                continue
            # If it's a spare, add 10 to the score and move on to the next roll
            elif roll == '/':
                score += 10
                current_roll += 1
                continue
            # Otherwise, it's a regular roll, so add its value to the score
            else:
                score += int(roll)
                current_roll += 1
                continue

        # If it's the second roll of the frame
        elif current_roll == 1:
            # If it's a spare, add the value of the next roll to the score
            if roll == '/':
                next_roll = bowling_round[bowling_round.index(roll) + 1]
                score += int(next_roll)
                current_roll += 1
                continue
            # Otherwise, it's a regular roll, so add its value to the score
            else:
                score += int(roll)
                current_roll += 1
                continue

        # If it's the third roll of the frame (spare bonus roll)
        elif current_roll == 2:
            # Add the value of the next two rolls to the score
            next_roll1 = bowling_round[bowling_round.index(roll) + 1]
            next_roll2 = bowling_round[bowling_round.index(roll) + 2]
            score += int(next_roll1) + int(next_roll2)
            current_roll = 0
            frame_num += 1

    # Return the final score
    return score