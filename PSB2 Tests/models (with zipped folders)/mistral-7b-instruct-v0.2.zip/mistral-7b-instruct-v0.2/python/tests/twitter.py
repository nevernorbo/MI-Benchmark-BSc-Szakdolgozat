def twitter(tweet):
    if len(tweet) > 140:
        return "Too many characters"
    elif len(tweet) == 0:
        return "You didn’t type anything"
    else:
        return "Your tweet has {} characters".format(len(tweet))

# # Test the function
# print(validate_tweet("This is a test tweet."))
# print(validate_tweet(""))
# print(validate_tweet("Your tweet here"))
# print(validate_tweet("Your tweet here. This is a longer test tweet."))