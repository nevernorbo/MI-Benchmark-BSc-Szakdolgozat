def find_pair(arr, target):
    complement = {}
    for i, num in enumerate(arr):
        complement[target - num] = i
        if complement.get(num, -1) != -1:
            return arr[i:i+2]

# # Test the function
# arr = [2, 7, 11, 15, 2, 3, 5, 10]
# pair = find_pair(arr, 9)
# if pair:
#     print("Pair that sums to the target:", pair)
# else:
#     print("No pair sums to the target.")