def paired_digits(string):
    total = 0
    for i in range(len(string)-1):
        if string[i] == string[i+1]:
            total += int(string[i])
    return total