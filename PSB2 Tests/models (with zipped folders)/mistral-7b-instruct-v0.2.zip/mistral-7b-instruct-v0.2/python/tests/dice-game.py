def dice_game(n, m):
    # Calculate the probability that Peter rolls a number greater than Colin
    peter_greater = [0] * (n + 1)
    for i in range(1, n + 1):
        peter_greater[i] = (1 / 6) ** n

    colin_max = max(6 ** m - 1, 1) * (1 / 6)
    colin_prob = [0] * (m + 1)
    for i in range(1, m + 1):
        colin_prob[i] = (1 / 6) ** m

    # Calculate the probability that Peter rolls a number less than or equal to Colin's maximum roll
    peter_less_or_equal = sum(colin_prob[:min(n, m) + 1])

    # Subtract the probability that Peter rolls less or equal from the probability that Peter rolls greater
    return peter_greater[-1] - peter_less_or_equal

# # Test the function
# n = 6 # Peter's die has 6 sides
# m = 4 # Colin's die has 4 sides
# prob = probability_peter_higher(n, m)
# print("Probability that Peter rolls strictly higher than Colin:", prob)