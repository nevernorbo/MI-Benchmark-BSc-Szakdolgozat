def bouncing_balls(starting_height, first_bounce_height, num_bounces):
    # Calculate the bounciness index
    bounciness_index = first_bounce_height / starting_height

    # Calculate the total distance that the ball travels
    total_distance = starting_height
    for i in range(num_bounces - 1):
        # The height of each subsequent bounce is the previous bounce height multiplied by the bounciness index
        bounce_height = first_bounce_height * (bounciness_index ** i)
        total_distance += 2 * bounce_height

    return total_distance