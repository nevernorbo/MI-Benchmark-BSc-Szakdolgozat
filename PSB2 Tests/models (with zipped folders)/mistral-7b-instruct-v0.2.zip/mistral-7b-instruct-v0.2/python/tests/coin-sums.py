def coin_sums(cents):
    # Initialize a dictionary to store the number of each type of coin
    coins = {'pennies': 0, 'nickels': 0, 'dimes': 0, 'quarters': 0}

    # Calculate the number of quarters needed
    quarters = cents // 25
    coins['quarters'] = quarters
    cents %= 25

    # Calculate the number of dimes needed
    dimes = cents // 10
    coins['dimes'] = dimes
    cents %= 10

    # Calculate the number of nickels needed
    nickels = cents // 5
    coins['nickels'] = nickels
    cents %= 5

    # Calculate the number of pennies needed
    pennies = cents
    coins['pennies'] = pennies

    # Return the dictionary of coin counts
    return coins