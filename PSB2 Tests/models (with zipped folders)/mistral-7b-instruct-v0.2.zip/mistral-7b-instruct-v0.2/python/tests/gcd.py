def gcd(a, b):
    while b != 0:
        a, b = b, a % b
    return a

# # Test the function
# x = 21
# y = 13
# print("The greatest common divisor of", x, "and", y, "is:", gcd(x, y))