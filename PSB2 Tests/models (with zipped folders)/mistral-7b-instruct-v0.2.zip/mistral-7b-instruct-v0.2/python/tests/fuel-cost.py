def fuel_cost(arr):
    return sum([int(num / 3) - 2 for num in arr])

# # Test the function
# arr = [4, 7, 12, 18, 21]
# sum_result = process_vector(arr)
# print("Sum of processed vector:", sum_result)