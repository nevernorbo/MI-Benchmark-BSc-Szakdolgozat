def mastermind(code, guess):
    code_set = set(code)
    guess_set = set(guess)
    white_pegs = 0
    black_pegs = 0

    for char in guess:
        if char in code_set:
            if char in guess[guess.index(char):]:
                black_pegs += 1
            else:
                white_pegs += 1
                code_set.remove(char)

    for char in code:
        if char in guess:
            if code.index(char) != guess.index(char):
                white_pegs += 1
        else:
            black_pegs += 1

    return white_pegs, black_pegs

# # Test the function
# code = "1234"
# guess = "3124"
# print("For the code '{}' and the guess '{}', the codemaster should give {} white pegs and {} black pegs.".format(code, guess, *mastermind_clues(code, guess)))