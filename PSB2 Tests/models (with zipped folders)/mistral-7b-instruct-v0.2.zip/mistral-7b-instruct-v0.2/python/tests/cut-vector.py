def cut_vector(arr):
    # Initialize variables
    min_diff = float('inf')
    left = right = result_left = result_right = []

    # Iterate through the array with a sliding window
    for i in range(len(arr)):
        while len(right) < len(arr) - i:
            right.append(arr[len(arr) - i - 1])
            diff = sum(right) - sum(arr[:i+1])
            if diff < min_diff:
                min_diff = diff
                result_left = arr[:i+1]
                result_right = right
        right.pop()

    return result_left, result_right

# # Test the function
# arr = [1, 2, 3, 4, 5, 6, 7, 8, 9]
# left, right = min_difference(arr)
# print("Left subvector:", left)
# print("Right subvector:", right)