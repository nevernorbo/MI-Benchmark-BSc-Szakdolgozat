def square_digits(number):
    str_number = str(number)
    result = ""
    for digit in str_number:
        result += str(int(digit) ** 2)
    return int(result) if len(result) > 0 else "0"

# # Test the function
# print(square_digits(12345))