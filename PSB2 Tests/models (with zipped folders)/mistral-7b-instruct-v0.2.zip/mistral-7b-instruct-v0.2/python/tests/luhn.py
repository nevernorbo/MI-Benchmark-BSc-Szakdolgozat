def luhn(number):
    digits = [int(d) for d in reversed(str(number))]
    for i, digit in enumerate(digits):
        if i % 2 == 0:
            digit *= 2
            digit = sum(int(d) for d in list(str(digit)))
        sum += digit
    return sum % 10 == 0

# # Test the function
# number = "4532001132143560"
# print("The credit card number '{}' is valid according to Luhn's algorithm: {}".format(number, luhn_check(number)))