def solve_boolean(expression):
    def and_operator(a, b):
        return a and b

    def or_operator(a, b):
        return a or b

    def not_operator(a):
        return not a

    def parse_expression(sub_expression):
        if sub_expression[0] == 'T':
            return True
        elif sub_expression[0] == 'F':
            return False
        elif sub_expression[0] == '&':
            return parse_expression(sub_expression[1:]) and parse_expression(sub_expression[len(sub_expression)-1:])
        elif sub_expression[0] == '|':
            return parse_expression(sub_expression[1:]) or parse_expression(sub_expression[len(sub_expression)-1:])
        elif sub_expression[0] == '~':
            return not parse_expression(sub_expression[1:])
        else:
            raise ValueError("Invalid boolean expression")

    return parse_expression(expression)