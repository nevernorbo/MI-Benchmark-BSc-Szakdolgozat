import math

def vector_distance(vector1, vector2):
    """
    Calculate the Euclidean distance between two n-dimensional vectors.

    :param vector1: A list or tuple of n floats representing the first vector.
    :param vector2: A list or tuple of n floats representing the second vector.
    :return: The Euclidean distance between the two vectors as a float.
    """
    distance = 0
    for i in range(len(vector1)):
        distance += (vector1[i] - vector2[i]) ** 2
    return math.sqrt(distance)

# # Test the function
# vector1 = (1.0, 2.0, 3.0)
# vector2 = (4.0, 5.0, 6.0)

# distance = euclidean_distance(vector1, vector2)
# print("The Euclidean distance between {} and {} is {}".format(vector1, vector2, distance))