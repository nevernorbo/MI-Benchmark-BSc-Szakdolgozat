def shopping_list(prices, discounts):
    total = 0
    for i in range(len(prices)):
        price_after_discount = prices[i] * (1 - discounts[i] / 100)
        total += price_after_discount
    return total