def indices_of_substring(text, target):
    start = 0
    indices = []
    while True:
        start = text.find(target, start)
        if start == -1:
            break
        indices.append(start)
        start += len(target)
    return indices

# # Test the function
# text = "The quick brown fox jumps over the lazy dog. The quick brown fox jumps over the lazy dog."
# target = "the quick brown fox"
# print("The indices of the target string '{}' in the text string '{}' are:".format(target, text))
# print(find_indices(text, target))