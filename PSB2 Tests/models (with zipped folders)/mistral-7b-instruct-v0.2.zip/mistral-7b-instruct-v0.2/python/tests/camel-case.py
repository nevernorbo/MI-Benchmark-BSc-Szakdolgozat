def camel_case(kebab_case_string):
    # Split the input string by "-" to get a list of words
    words = kebab_case_string.split('-')

    # Convert the first word to uppercase and join the list of words with an empty string
    camel_case_words = words[0].upper() + ''.join(word.title() for word in words[1:])

    # Return the resulting camelCase string
    return camel_case_words