def leaders(numbers):
    leaders = []
    max_num = numbers[-1]
    for num in reversed(numbers):
        if num >= max_num:
            leaders.append(num)
            max_num = num
    leaders.append(max_num)
    return leaders

# # Test the function
# numbers = [1, 2, 3, 4, 5, 6, 5, 4, 3, 2, 1]
# print("The leaders in the vector [", end="")
# print(*find_leaders(numbers), sep=", ", sep="]", sep="")
# print("] are:")