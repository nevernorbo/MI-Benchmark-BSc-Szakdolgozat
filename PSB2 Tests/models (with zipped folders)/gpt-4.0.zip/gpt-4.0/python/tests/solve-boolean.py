def solve_boolean(expr):
    # Convert expression to a more easily parsed format using booleans and operators
    expr = expr.replace('T', 'True').replace('F', 'False')

    # Split the expression by spaces for easier parsing if spaces are used
    tokens = expr.split()
    
    # Evaluate the expression using Python's eval (considering security risks in real applications)
    result = eval(' '.join(tokens))
    
    return result

# # Example usage:
# expression = "T & F | T"
# result = evaluate_boolean_expression(expression)
# print(f"Result of the Boolean expression '{expression}': {result}")
