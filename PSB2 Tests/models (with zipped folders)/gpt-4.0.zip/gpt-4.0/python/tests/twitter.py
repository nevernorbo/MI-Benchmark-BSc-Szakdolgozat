def twitter(tweet):
    # Check if the tweet is empty
    if len(tweet) == 0:
        return "You didn’t type anything"
    
    # Check if the tweet exceeds 140 characters
    elif len(tweet) > 140:
        return "Too many characters"
    
    # Otherwise, the tweet is within the allowed length
    else:
        return f"Your tweet has {len(tweet)} characters"

# # Example usage:
# print(validate_tweet(""))  # Output: "You didn’t type anything"
# print(validate_tweet("Hello, this is a test tweet that definitely does not exceed 140 characters."))  # Output with character count
# print(validate_tweet("This is a really long tweet intended to simulate the effect of tweeting more than one hundred and forty characters, which is traditionally the limit for a tweet before extended tweet features were implemented."))  # Output: "Too many characters"
