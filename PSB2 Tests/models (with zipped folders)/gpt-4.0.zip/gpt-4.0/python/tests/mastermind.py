def mastermind(code, guess):
    black_pegs = 0
    white_pegs = 0

    # To track which positions have already been considered for black or white pegs
    used_in_code = [False] * 4
    used_in_guess = [False] * 4

    # First pass to count black pegs
    for i in range(4):
        if guess[i] == code[i]:
            black_pegs += 1
            used_in_code[i] = True
            used_in_guess[i] = True

    # Second pass to count white pegs
    for i in range(4):
        if not used_in_guess[i]:
            for j in range(4):
                if not used_in_code[j] and guess[i] == code[j]:
                    white_pegs += 1
                    used_in_code[j] = True
                    break

    return black_pegs, white_pegs

# # Example usage:
# code = "RGBY"
# guess = "GGRR"
# black_pegs, white_pegs = mastermind_feedback(code, guess)
# print(f"Black pegs: {black_pegs}, White pegs: {white_pegs}")
