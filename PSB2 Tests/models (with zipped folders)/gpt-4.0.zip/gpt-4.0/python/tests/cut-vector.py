def cut_vector(vector):
    total_sum = sum(vector)
    min_difference = float('inf')
    best_index = 0
    running_sum = 0

    # Iterate over the vector to find the optimal cutting point
    for i in range(len(vector) - 1):
        running_sum += vector[i]
        remaining_sum = total_sum - running_sum
        difference = abs(running_sum - remaining_sum)

        # Update the minimum difference and best index
        if difference < min_difference:
            min_difference = difference
            best_index = i

    # Return the two subvectors based on the best_index
    left_subvector = vector[:best_index + 1]
    right_subvector = vector[best_index + 1:]

    return left_subvector, right_subvector

# # Example usage
# vector = [1, 2, 3, 4, 5, 6]
# left, right = find_min_difference_cut(vector)
# print("Left Subvector:", left)
# print("Right Subvector:", right)
