def dice_game(n, m):
    favorable_outcomes = 0

    # Loop over each side of Peter's die
    for peter_roll in range(1, n + 1):
        # Count how many rolls of Colin's die are lower than Peter's current roll
        favorable_outcomes += max(0, peter_roll - 1)

    # Total outcomes when both dice are rolled
    total_outcomes = n * m

    # Calculate probability
    probability = favorable_outcomes / total_outcomes
    return probability

# # Example usage
# n = 4  # Peter's die has 4 sides
# m = 6  # Colin's die has 6 sides
# prob = probability_peter_wins(n, m)
# print(f"The probability that Peter rolls strictly higher than Colin is {prob:.4f}")
