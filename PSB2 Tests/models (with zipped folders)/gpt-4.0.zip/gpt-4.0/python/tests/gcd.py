def gcd(a, b):
    while b != 0:
        a, b = b, a % b
    return a

# # Example usage:
# num1 = 36
# num2 = 60
# result = gcd(num1, num2)
# print(f"The largest integer that divides {num1} and {num2} evenly is {result}")
