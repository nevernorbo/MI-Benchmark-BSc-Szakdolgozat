def square_digits(num):
    # Convert the number to a string to iterate over each digit
    result = ''.join(str(int(digit)**2) for digit in str(num))
    return result

# # Example usage:
# number = 9119
# result = square_digits(number)
# print(result)  # Outputs: "811181"
