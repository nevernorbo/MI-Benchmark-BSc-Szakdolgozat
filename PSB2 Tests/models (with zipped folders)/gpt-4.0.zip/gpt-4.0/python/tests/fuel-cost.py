def fuel_cost(numbers):
    transformed_sum = 0
    for number in numbers:
        # Divide by 3, round down automatically with integer division, subtract 2
        transformed_value = number // 3 - 2
        transformed_sum += transformed_value
    return transformed_sum

# # Example usage
# numbers = [9, 12, 15, 18]  # This list can be any list of positive integers
# total_transformed_sum = sum_transformed_integers(numbers)
# print("Total sum of transformed integers:", total_transformed_sum)
