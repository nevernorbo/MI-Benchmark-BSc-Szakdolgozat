def paired_digits(s):
    total_sum = 0
    # Iterate through the string until the second last character
    for i in range(len(s) - 1):
        # Check if the current digit is the same as the next one
        if s[i] == s[i + 1]:
            total_sum += int(s[i])  # Convert the current character to integer and add to the sum

    return total_sum

# # Example usage:
# digits_string = "112334455"
# result = sum_of_same_following_digits(digits_string)
# print("Sum of digits whose following digit is the same:", result)  # Outputs: 4 (1+1+3+4)
