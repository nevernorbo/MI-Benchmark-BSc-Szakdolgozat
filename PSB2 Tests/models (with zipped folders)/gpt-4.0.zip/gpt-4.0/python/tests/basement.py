def basement(nums):
    current_sum = 0
    for index, value in enumerate(nums):
        current_sum += value
        if current_sum < 0:
            return index
    return None  # Return None if no negative sum is found

# # Example usage:
# nums = [1, 2, -5, 1, 2]
# print(first_negative_sum_index(nums))  # Output will depend on the input values
