def snow_day(initial_snow, snowfall_rate, melt_proportion, hours):
    snow = initial_snow  # Start with the initial amount of snow on the ground

    for _ in range(hours):
        # Each hour, add the snowfall rate
        snow += snowfall_rate
        # Then, apply the melting effect
        snow -= snow * melt_proportion

    return snow

# # Example usage
# initial_snow = 5.0  # Initial amount of snow in inches
# snowfall_rate = 2.0  # Inches of snow falling per hour
# melt_proportion = 0.1  # 10% of the snow melts each hour
# hours = 10  # Number of hours

# final_snow_amount = snow_on_ground(initial_snow, snowfall_rate, melt_proportion, hours)
# print(f"Amount of snow on the ground after {hours} hours: {final_snow_amount:.2f} inches")
