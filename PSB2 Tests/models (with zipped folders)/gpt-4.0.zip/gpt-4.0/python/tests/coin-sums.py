def coin_sums(cents):
    coins = {
        "quarters": 0,
        "dimes": 0,
        "nickels": 0,
        "pennies": 0
    }
    
    # Calculate the number of quarters
    coins["quarters"], cents = divmod(cents, 25)
    
    # Calculate the number of dimes
    coins["dimes"], cents = divmod(cents, 10)
    
    # Calculate the number of nickels
    coins["nickels"], cents = divmod(cents, 5)
    
    # The remaining cents are all pennies
    coins["pennies"] = cents
    
    return coins["quarters"], coins["dimes"], coins["nickels"], coins["pennies"]

# # Example usage
# total_cents = 99
# quarters, dimes, nickels, pennies = min_coins(total_cents)
# print(f"Quarters: {quarters}, Dimes: {dimes}, Nickels: {nickels}, Pennies: {pennies}")
