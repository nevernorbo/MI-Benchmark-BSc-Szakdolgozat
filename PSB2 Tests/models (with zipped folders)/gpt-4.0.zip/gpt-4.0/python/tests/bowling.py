def bowling(rolls):
    score = 0
    frame_index = 0
    roll_index = 0

    # Process each frame
    for frame in range(10):
        if rolls[roll_index] == 'X':  # Strike
            score += 10 + strike_bonus(rolls, roll_index)
            roll_index += 1
        elif rolls[roll_index + 1] == '/':  # Spare
            score += 10 + spare_bonus(rolls, roll_index)
            roll_index += 2
        else:  # Normal frame
            score += sum_pins(rolls[roll_index:roll_index + 2])
            roll_index += 2
        frame_index += 1

    return score

def strike_bonus(rolls, index):
    bonus = 0
    # Add next two rolls to the bonus, checking for length and special characters
    if index + 1 < len(rolls):
        bonus += convert_pin(rolls[index + 1])
        if index + 2 < len(rolls):
            if rolls[index + 2] == '/':
                bonus += 10 - convert_pin(rolls[index + 1])
            else:
                bonus += convert_pin(rolls[index + 2])
    return bonus

def spare_bonus(rolls, index):
    # Add the next roll to the bonus, checking for length
    if index + 2 < len(rolls):
        return convert_pin(rolls[index + 2])
    return 0

def sum_pins(frame):
    # Sum the pins in two rolls, accounting for spares
    if frame[1] == '/':
        return 10
    return convert_pin(frame[0]) + convert_pin(frame[1])

def convert_pin(roll):
    # Convert roll notation to pin count
    if roll in '123456789':
        return int(roll)
    elif roll == '-':
        return 0
    return 10  # for 'X'

# # Example usage
# game = 'X7/9-X-88/-6XXX81'
# print("Total score:", bowling_score(game))
