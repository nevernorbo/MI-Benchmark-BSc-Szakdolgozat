def camel_case(s):
    # Split the string into kebab-case groups
    groups = s.split()
    
    # Process each group separately
    camel_case_groups = []
    for group in groups:
        parts = group.split('-')
        # Convert the first part to lower case, and capitalize the initial letter of subsequent parts
        camel_case = parts[0].lower() + ''.join(word.capitalize() for word in parts[1:])
        camel_case_groups.append(camel_case)
    
    # Join all the processed groups back with a space
    return ' '.join(camel_case_groups)

# # Example usage
# kebab_string = "camel-case example-test-string"
# camel_case_string = kebab_to_camel_case(kebab_string)
# print(camel_case_string)  # Outputs: "camelCase exampleTestString"
