def substitution_cipher(map_from, map_to, message):
    # Create a translation dictionary from the mapping strings
    translation_dict = {from_char: to_char for from_char, to_char in zip(map_from, map_to)}
    
    # Translate the message using the dictionary
    translated_message = ''.join(translation_dict.get(char, char) for char in message)
    
    return translated_message

# # Example usage:
# map_from = "abc"
# map_to = "xyz"
# message = "aabbcc"
# decoded_message = apply_cipher(map_from, map_to, message)
# print(decoded_message)  # Outputs: "xxyyzz"
