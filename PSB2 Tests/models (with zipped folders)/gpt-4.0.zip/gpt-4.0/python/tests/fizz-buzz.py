def fizz_buzz(x):
    # Check if x is divisible by both 3 and 5
    if x % 3 == 0 and x % 5 == 0:
        return "FizzBuzz"
    # Check if x is divisible by 3
    elif x % 3 == 0:
        return "Fizz"
    # Check if x is divisible by 5
    elif x % 5 == 0:
        return "Buzz"
    # If none of the conditions are met, return the string version of x
    else:
        return str(x)

# # Example usage
# print(fizz_buzz(15))  # Outputs "FizzBuzz"
# print(fizz_buzz(9))   # Outputs "Fizz"
# print(fizz_buzz(10))  # Outputs "Buzz"
# print(fizz_buzz(7))   # Outputs "7"
