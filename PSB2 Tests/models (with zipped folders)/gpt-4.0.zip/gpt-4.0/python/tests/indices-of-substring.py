def indices_of_substring(text, target):
    indices = []
    # The length of the target determines how far we can go in the text
    target_length = len(target)
    for i in range(len(text) - target_length + 1):  # Ensure the substring can fit
        # Check the substring starting at index i
        if text[i:i + target_length] == target:
            indices.append(i)
    return indices

# # Example usage
# text = "abcxabcdabxabcdabcdabcy"
# target = "abcd"
# indices = find_target_indices(text, target)
# print("Indices of target in text:", indices)
