def middle_character(s):
    length = len(s)
    if length % 2 == 1:  # Odd length
        # Middle character is at length//2
        return s[length // 2]
    else:  # Even length
        # Middle two characters are at length//2 - 1 and length//2
        return s[length // 2 - 1:length // 2 + 1]

# # Example usage
# print(find_middle_characters("hello"))  # Outputs: "l"
# print(find_middle_characters("function"))  # Outputs: "ct"
