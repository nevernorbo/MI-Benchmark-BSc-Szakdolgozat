def bouncing_balls(initial_height, first_bounce_height, num_bounces):
    # Calculate the bounciness index
    index = first_bounce_height / initial_height
    
    # Initialize total distance with the initial drop
    total_distance = initial_height
    
    # Current height for the current bounce
    current_height = first_bounce_height
    
    # Sum up the distances for each bounce
    for _ in range(num_bounces):
        total_distance += 2 * current_height  # up and down for each bounce
        current_height *= index  # height reduces by the index each bounce
    
    return total_distance

# # Example usage
# initial_height = 10  # meters
# first_bounce_height = 6  # meters
# num_bounces = 5
# total_distance = calculate_total_distance(initial_height, first_bounce_height, num_bounces)
# print("Total distance traveled:", total_distance)
