def find_pair(nums, target):
    # Dictionary to store the numbers encountered and their indices
    num_map = {}
    
    # Iterate over the list of numbers
    for i, num in enumerate(nums):
        # Calculate the complement needed to reach the target sum
        complement = target - num
        
        # Check if the complement exists in the dictionary
        if complement in num_map:
            return [complement, num]  # Return the pair that sums to the target
        
        # Store the current number in the dictionary
        num_map[num] = i
        
    return []  # Return an empty list if no pair is found

# # Example usage
# nums = [2, 7, 11, 15]
# target = 9
# result = find_two_sum(nums, target)
# print("Pair found:", result)  # Output should be [2, 7] if the pair sums to 9
