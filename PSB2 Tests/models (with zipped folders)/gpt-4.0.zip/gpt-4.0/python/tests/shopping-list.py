def shopping_list(prices, discounts):
    total = 0
    # Iterate over both lists simultaneously
    for price, discount in zip(prices, discounts):
        # Calculate discounted price
        discounted_price = price * (1 - discount / 100)
        # Add to total
        total += discounted_price
    return total

# # Example usage
# prices = [100.0, 200.0, 150.0]  # Prices of goods
# discounts = [10, 20, 15]  # Corresponding percent discounts for each item

# total_cost = total_price_after_discount(prices, discounts)
# print("Total cost of the shopping trip after discounts:", total_cost)
