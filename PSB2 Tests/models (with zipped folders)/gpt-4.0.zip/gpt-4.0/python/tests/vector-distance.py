import math

def vector_distance(vector1, vector2):
    if len(vector1) != len(vector2):
        raise ValueError("Both vectors must be of the same dimension.")
    
    # Sum the squared differences of corresponding elements
    sum_squared_differences = sum((x - y) ** 2 for x, y in zip(vector1, vector2))
    
    # Take the square root of the sum of squared differences
    distance = math.sqrt(sum_squared_differences)
    return distance

# # Example usage:
# vector1 = [1.0, 2.0, 3.0]
# vector2 = [4.0, 5.0, 6.0]
# print("Euclidean distance:", euclidean_distance(vector1, vector2))
