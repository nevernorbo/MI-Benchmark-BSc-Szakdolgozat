def luhn(digits):
    # Assuming digits is a list of 16 integers
    if len(digits) != 16:
        raise ValueError("Input must be a list of 16 digits.")

    transformed_digits = []
    
    # Process each digit; note the index i starts from 0, so adjust for Luhn's double-every-other from the right
    for i in range(len(digits)):
        if (len(digits) - i) % 2 == 0:  # Double the digit if it's every other digit from the right
            doubled = digits[i] * 2
            # Subtract 9 from doubled values greater than 9
            if doubled > 9:
                doubled -= 9
            transformed_digits.append(doubled)
        else:
            transformed_digits.append(digits[i])
    
    # Sum all the digits after transformation
    total_sum = sum(transformed_digits)
    return total_sum

# # Example usage:
# credit_card_digits = [4, 5, 5, 6, 7, 3, 7, 5, 8, 6, 8, 9, 9, 8, 5, 1]
# result = luhn_algorithm(credit_card_digits)
# print("Sum of transformed digits:", result)
