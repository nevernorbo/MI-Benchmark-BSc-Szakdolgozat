def spin_words(sentence):
    # Split the sentence into words
    words = sentence.split()
    
    # Process each word and reverse if it has 5 or more letters
    reversed_words = [(word[::-1] if len(word) >= 5 else word) for word in words]
    
    # Join all words back into a single string
    return ' '.join(reversed_words)

# # Example usage:
# sentence = "Hey there, this should definitely be reversed"
# result = reverse_long_words(sentence)
# print(result)
