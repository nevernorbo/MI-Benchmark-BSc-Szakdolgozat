def leaders(nums):
    leaders = []
    max_right = float('-inf')  # Initialize to negative infinity

    # Traverse from right to left
    for num in reversed(nums):
        if num >= max_right:
            leaders.append(num)
            max_right = num

    # The leaders are collected in reverse order, so reverse them before returning
    return leaders[::-1]

# # Example usage
# nums = [16, 17, 4, 3, 5, 2]
# leaders = find_leaders(nums)
# print("Leaders in the array:", leaders)
