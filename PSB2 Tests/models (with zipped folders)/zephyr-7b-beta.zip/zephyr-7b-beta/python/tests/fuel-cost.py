def fuel_cost(vector):
    transformed = [int(num / 3 - 2) for num in vector]
    return sum(transformed)

# vector = [12, 3, 18, 5, 15, 10]