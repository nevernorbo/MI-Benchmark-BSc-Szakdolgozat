def spin_words(string):
    reversed_words = []
    for word in string.split():
        if len(word) >= 5:
            reversed_words.append(word[::-1])
        else:
            reversed_words.append(word)
    return " ".join(reversed_words)

# # Example usage
# print(spin_words("This is a sample string"))