def find_pair(vector, target):
    freq = {}
    for num in vector:
        freq[num] = freq.get(num, 0) + 1
    for num1 in freq:
        num2 = target - num1
        if num2 in freq and num1 != num2 and freq[num1] > 0 and freq[num2] > 0:
            return num1, num2
    raise ValueError("No two elements sum to the target integer")

# vector = [2, 5, 3, 1, 4, 7]
# target = 6
# print(find_elements(vector, target))