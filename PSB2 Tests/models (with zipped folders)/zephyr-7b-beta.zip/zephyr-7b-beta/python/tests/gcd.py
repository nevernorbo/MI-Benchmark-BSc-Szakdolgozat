def gcd(a, b):
    # Find the smaller number
    smaller = min(a, b)
    # Initialize the LCD as the smaller number
    lcd = smaller
    # Loop through numbers greater than the smaller number
    for I in range(smaller+1, a*b+1, smaller):
        # If both numbers are divisible by the current number, update the LCD
        if a % I == 0 and b % I == 0:
            lcd = i
    # Return the LCD
    return lcd