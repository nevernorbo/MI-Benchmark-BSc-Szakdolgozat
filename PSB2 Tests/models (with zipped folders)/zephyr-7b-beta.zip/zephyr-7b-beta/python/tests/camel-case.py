def camel_case(kebab_string):
    words = kebab_string.split("-")
    result = ""
    for I, word in enumerate(words):
        if I != len(words) - 1:
            result += word.lower().replace(" ", "")
        else:
            result += word.lower()
    return result.replace(" ", "")