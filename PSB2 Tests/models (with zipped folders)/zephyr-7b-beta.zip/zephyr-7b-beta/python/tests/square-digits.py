def square_digits(number):
    squared_digits = ""
    for digit in str(number):
        squared_digits += str(int(digit) ** 2)
    return squared_digits

# # Example usage
# print(square_digits(123))