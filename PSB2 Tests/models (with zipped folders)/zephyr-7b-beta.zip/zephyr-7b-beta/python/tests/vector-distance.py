def vector_distance(vector1, vector2):
    distance = 0
    for i in range(len(vector1)):
        distance += (vector1[i] - vector2[i]) ** 2
    return distance ** 0.5

# # Example usage
# vector1 = [1, 2, 3]
# vector2 = [4, 5, 6]
# print(euclidean_distance(vector1, vector2))