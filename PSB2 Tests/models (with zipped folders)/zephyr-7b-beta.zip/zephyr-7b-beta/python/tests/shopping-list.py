def shopping_list(prices: list[float], discounts: list[float]) -> float:
    total_price = 0
    for I in range(len(prices)):
        discounted_price = prices[i] * (1 - discounts[i] / 100)
        total_price += discounted_price
    return total_price