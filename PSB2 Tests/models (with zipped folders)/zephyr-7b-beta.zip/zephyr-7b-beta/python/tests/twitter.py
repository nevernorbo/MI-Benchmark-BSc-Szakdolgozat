def twitter(tweet):
    if len(tweet) > 140:
        return "Too many characters"
    elif len(tweet) == 0:
        return "You didn’t type anything"
    else:
        return "Your tweet has " + str(len(tweet)) + " characters"

# # Example usage
# print(validate_tweet("This is a sample tweet"))
# print(validate_tweet(""))
# print(validate_tweet("X" * 141))