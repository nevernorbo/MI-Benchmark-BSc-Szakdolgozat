def leaders(numbers):
    # Initialize the leader as the last element in the vector
    leader = numbers[-1]
    # Initialize an empty list to store the leaders
    leaders = [numbers[-1]]
    # Loop through the vector from the second last element
    for I in range(len(numbers)-2, -1, -1):
        # If the current element is greater than or equal to the leader, update the leader and add it to the list of leaders
        if numbers[i] >= leader:
            leader = numbers[i]
            leaders.append(numbers[i])
    # Return the list of leaders
    return leaders