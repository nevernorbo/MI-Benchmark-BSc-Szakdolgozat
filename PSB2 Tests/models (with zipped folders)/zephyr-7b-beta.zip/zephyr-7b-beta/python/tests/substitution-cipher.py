def substitution_cipher(message, cipher1, cipher2):
    deciphered = ""
    for char in message:
        if char.isalpha():
            deciphered += cipher2[cipher1.find(char)]
        else:
            deciphered += char
    return deciphered

# # Example usage
# cipher1 = "abcdefghijklmnopqrstuvwxyz"
# cipher2 = "zyxwvutsrqponmlkjihgfedcba"
# message = "Kjx hxq vxqb xvq!"
# print(substitution_cipher(message, cipher1, cipher2))