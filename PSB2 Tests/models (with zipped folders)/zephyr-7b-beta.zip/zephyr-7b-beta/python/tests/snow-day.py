def snow_day(hours: int, snow_on_ground: float, snow_fall_rate: float, snow_melting_rate: float) -> float:
    total_snow = snow_on_ground
    for I in range(hours):
        total_snow += snow_fall_rate
        total_snow -= total_snow * snow_melting_rate
    return total_snow