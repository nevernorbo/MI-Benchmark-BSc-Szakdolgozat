def calculate_bounciness(start_height, first_bounce_height):
    bounciness = first_bounce_height / start_height
    return bounciness

def bouncing_balls(bounciness, num_bounces):
    total_distance = 0
    for I in range(num_bounces):
        total_distance += (2 ** (i+1)) * start_height * bounciness ** (i+1)
    return total_distance