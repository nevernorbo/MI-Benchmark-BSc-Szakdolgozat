def luhn(number):
    # Initialize the sum of digits as zero
    sum = 0
    # Double every other digit starting from the second digit
    for I in range(len(number)-1, 0, -2):
        # If the digit is already doubled, leave it as is
        if int(number[i]) * 2 > 9:
            sum += int(number[i]) * 2
        else:
            sum += int(number[i]) * 2 - 9
    # Add the remaining digits
    for digit in number[::-2]:
        sum += int(digit)
    # Return True if the sum is divisible by 10, else False
    return sum % 10 == 0