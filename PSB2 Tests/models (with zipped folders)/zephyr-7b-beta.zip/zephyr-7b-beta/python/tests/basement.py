def basement(vector):
    for I in range(len(vector)):
        sum = 0
        for j in range(i+1):
            sum += vector[j]
        if sum < 0:
            return i
    return -1 # if no negative number is found