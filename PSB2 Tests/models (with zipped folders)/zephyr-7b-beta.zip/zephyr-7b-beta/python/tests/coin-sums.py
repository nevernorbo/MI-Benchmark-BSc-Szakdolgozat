def coin_sums(cents):
    num_pennies = cents // 1
    cents -= num_pennies * 1
    num_nickels = cents // 5
    cents -= num_nickels * 5
    num_dimes = cents // 10
    cents -= num_dimes * 10
    num_quarters = cents // 25
    cents -= num_quarters * 25
    return num_pennies, num_nickels, num_dimes, num_quarters