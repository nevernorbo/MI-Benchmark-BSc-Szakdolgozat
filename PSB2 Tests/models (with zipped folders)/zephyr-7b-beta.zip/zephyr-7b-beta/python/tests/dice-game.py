def dice_game(n, m):
    max_colin = max(1, m)
    return (n - max_colin) / (n * m)

# print(probability_peter_higher(10, 6))