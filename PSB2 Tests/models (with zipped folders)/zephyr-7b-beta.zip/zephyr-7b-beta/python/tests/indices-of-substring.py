def indices_of_substring(text, target):
    # Initialize an empty list to store the indices
    indices = []
    # Initialize the index of the target string in the text
    start = 0
    # Loop through the text string
    while True:
        # Find the next occurrence of the target string in the text
        next_start = text.find(target, start)
        # If the target string is not found, break out of the loop
        if next_start == -1:
            break
        # If the target string overlaps itself in the text, add all indices
        if next_start > start:
            indices.extend(range(start, next_start))
        # Update the starting index for the next iteration
        start = next_start + 1
    # Return the list of indices
    return indices