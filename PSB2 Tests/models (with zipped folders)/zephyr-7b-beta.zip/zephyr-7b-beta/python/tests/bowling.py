def bowling(bowling_string):
    score = 0
    frame = 0
    strikes = 0
    spares = 0
    for I in range(len(bowling_string)):
        if bowling_string[i] == 'X':
            strikes += 1
            if frame == 9:
                score += 20 + int(bowling_string[i+1]) + int(bowling_string[i+2])
            else:
                score += 26
                frame += 1
        elif bowling_string[i] == '/':
            spares += 1
            if frame == 9:
                score += 20 + int(bowling_string[i+1])
            else:
                score += 15 + int(bowling_string[i+1])
                frame += 1
        else:
            roll = int(bowling_string[i])
            if strikes > 0:
                strikes -= 1
            elif spares > 0:
                spares -= 1
            score += roll
            frame += 1
    return score