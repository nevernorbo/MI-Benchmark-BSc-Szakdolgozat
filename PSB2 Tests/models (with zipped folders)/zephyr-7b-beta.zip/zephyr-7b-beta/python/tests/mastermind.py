def mastermind(code, guess):
    # Initialize the number of black and white pegs to zero
    black_pegs = 0
    white_pegs = 0
    # Loop through the code and guess
    for I in range(4):
        # If the characters match, increment both black and white pegs
        if code[i] == guess[i]:
            black_pegs += 1
            white_pegs += 1
        # If the characters don't match but are present in both, increment white pegs
        elif code[i] in guess and code[i] != guess[i]:
            white_pegs += 1
    # Return a tuple containing the number of black and white pegs
    return black_pegs, white_pegs