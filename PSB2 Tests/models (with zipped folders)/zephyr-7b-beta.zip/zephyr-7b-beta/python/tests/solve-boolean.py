def solve_boolean(expression: str) -> bool:
    operators = {"|": lambda x, y: x or y, "&": lambda x, y: x and y}
    operands = [x for x in expression if x not in operators.keys()]
    operands = [operators[op](*map(solve_boolean, operand.split())) for op, operand in zip(expression[::2], expression[1::2])]
    return operands[0]