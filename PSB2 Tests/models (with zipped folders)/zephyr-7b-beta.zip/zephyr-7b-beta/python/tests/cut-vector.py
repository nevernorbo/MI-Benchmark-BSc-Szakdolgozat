def cut_vector(vector):
    n = len(vector)
    left = right = 0
    min_diff = float('inf')
    for I in range(n):
        for j in range(i+1, n):
            diff = abs(vector[i] - vector[j])
            if diff < min_diff:
                min_diff = diff
                left = i
                right = j
    return left, right

def split_vector(vector, left, right):
    return vector[:left+1], vector[right+1:]

# vector = [12, 3, 18, 5, 15, 10]
# left, right = find_cutting_point(vector)
# print(split_vector(vector, left, right))