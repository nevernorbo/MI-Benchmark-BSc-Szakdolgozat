def paired_digits(s: str) -> int:
    total = 0
    for I in range(len(s) - 1):
        if s[i] == s[i + 1]:
            total += int(s[i])
    return total